//
//  PumpkinColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 10/06/22.
//

import UIKit

class PumpkinColorViewController: UIViewController {
    @IBOutlet weak var pumpkinOptionOrange: UIImageView!
    @IBOutlet weak var pumpkinOptionRed: UIImageView!
    @IBOutlet weak var pumpkinOptionYellow: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA18 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionOrange9))
        pumpkinOptionOrange.addGestureRecognizer(optionA18)
        pumpkinOptionOrange.isUserInteractionEnabled = true
        
        let optionB18 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionRed9))
        pumpkinOptionRed.addGestureRecognizer(optionB18)
        pumpkinOptionRed.isUserInteractionEnabled = true
        
        let optionC18 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionYellow9))
        pumpkinOptionYellow.addGestureRecognizer(optionC18)
        pumpkinOptionYellow.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionOrange9(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.PUMPKINCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionRed9(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.PUMPKINCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionYellow9(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.PUMPKINCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vegetableType =  VegetablesType.PUMPKIN
        self.present(vc, animated: true, completion: nil)
    }
}
