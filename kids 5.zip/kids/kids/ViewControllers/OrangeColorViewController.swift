//
//  OrangeColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 20/05/22.
//

import UIKit

class OrangeColorViewController: UIViewController {
    
    
    @IBOutlet weak var optionBlue3: UIImageView!
    
    @IBOutlet weak var optionOrange3: UIImageView!
    
    @IBOutlet weak var optionGreen3: UIImageView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA8 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlue3))
        optionBlue3.addGestureRecognizer(optionA8)
        optionBlue3.isUserInteractionEnabled = true
        
        let optionB8 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionOrange3))
        optionOrange3.addGestureRecognizer(optionB8)
        optionOrange3.isUserInteractionEnabled = true
        
        let optionC8 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionGreen3))
        optionGreen3.addGestureRecognizer(optionC8)
        optionGreen3.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionBlue3(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.ORANGECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionOrange3(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.ORANGECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionGreen3(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.ORANGECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.fruitType =  FruitsType.ORANGE
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
}
