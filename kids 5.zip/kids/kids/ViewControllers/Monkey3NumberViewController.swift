//
//  Monkey3NumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 23/06/22.
//

import UIKit

class Monkey3NumberViewController: UIViewController {
    
    @IBOutlet weak var monkeyButton3: UIImageView!
    
    @IBOutlet weak var monkeyButton4: UIImageView!
    
    @IBOutlet weak var monkeyButton5: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let optionA17 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption36))
        monkeyButton5.addGestureRecognizer(optionA17)
        monkeyButton5.isUserInteractionEnabled = true
        
        let optionB17 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption46))
        monkeyButton3.addGestureRecognizer(optionB17)
        monkeyButton3.isUserInteractionEnabled = true
        
        let optionC17 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption56))
        monkeyButton4.addGestureRecognizer(optionC17)
        monkeyButton4.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption36(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.monkeyType = .MONKEY3

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption46(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.monkeyType = .MONKEY3
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption56(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.monkeyType = .MONKEY3

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.MONKEY
        self.present(vc, animated: true, completion: nil)
    }
    
}
