//
//  FruitsKidsViewController.swift
//  kids
//
//  Created by CIPL0957 on 17/05/22.
//

import UIKit

class FruitsKidsViewController: UIViewController {

    @IBOutlet weak var appleImage: UIImageView!
    
    @IBOutlet weak var bananaImage: UIImageView!
    
    @IBOutlet weak var mangoImage: UIImageView!
    
    @IBOutlet weak var orangeImage: UIImageView!
    
    @IBOutlet weak var strawberyImage: UIImageView!
    
    @IBOutlet weak var guavaImage: UIImageView!
    
    @IBOutlet weak var watermelonImage: UIImageView!
    
    @IBOutlet weak var grapeImage: UIImageView!
    
    @IBOutlet weak var pineaplleImage: UIImageView!
    
    @IBOutlet weak var lemonImage: UIImageView!
    
    
    var textValue : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let tapGR4 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped4))
        appleImage.addGestureRecognizer(tapGR4)
        appleImage.isUserInteractionEnabled = true
        
        
        
        
        let tapGR5 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped5))
        bananaImage.addGestureRecognizer(tapGR5)
        bananaImage.isUserInteractionEnabled = true
        
        
        
        
        let tapGR6 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped6))
        mangoImage.addGestureRecognizer(tapGR6)
        mangoImage.isUserInteractionEnabled = true
        
        
        
        
        
        let tapGR7 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped7))
        orangeImage.addGestureRecognizer(tapGR7)
        orangeImage.isUserInteractionEnabled = true
        
        let tapGR8 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped8))
        strawberyImage.addGestureRecognizer(tapGR8)
        strawberyImage.isUserInteractionEnabled = true
        
        let tapGR9 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped9))
        guavaImage.addGestureRecognizer(tapGR9)
        guavaImage.isUserInteractionEnabled = true
        
        let tapGR10 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped10))
        watermelonImage.addGestureRecognizer(tapGR10)
        watermelonImage.isUserInteractionEnabled = true
        
        let tapGR11 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped11))
        grapeImage.addGestureRecognizer(tapGR11)
        grapeImage.isUserInteractionEnabled = true
        
        let tapGR12 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped12))
        pineaplleImage.addGestureRecognizer(tapGR12)
        pineaplleImage.isUserInteractionEnabled = true
        
        let tapGR13 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped13))
        lemonImage.addGestureRecognizer(tapGR13)
        lemonImage.isUserInteractionEnabled = true
    }
    
    @objc func imageTapped4(sender: UITapGestureRecognizer) {
//            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
        vc.modalTransitionStyle = .crossDissolve
                vc.fruitType =  FruitsType.APPLE
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
//           }
        }
    
    @objc func imageTapped5(sender: UITapGestureRecognizer) {
//            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
        vc.modalTransitionStyle = .crossDissolve
                vc.fruitType =  FruitsType.BANANA
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
//           }
        }
    @objc func imageTapped6(sender: UITapGestureRecognizer) {
//            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
        vc.modalTransitionStyle = .crossDissolve
                vc.fruitType =  FruitsType.MANGO
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
//           }
        }
    
    @objc func imageTapped7(sender: UITapGestureRecognizer) {
//            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
        vc.modalTransitionStyle = .crossDissolve
                vc.fruitType =  FruitsType.ORANGE
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
//           }
        }
    @objc func imageTapped8(sender: UITapGestureRecognizer) {
//            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
        vc.modalTransitionStyle = .crossDissolve
               vc.fruitType =  FruitsType.STRAWBERY
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
//           }
        }
    
    @objc func imageTapped9(sender: UITapGestureRecognizer) {
//            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                
                vc.modalPresentationStyle = .fullScreen
        vc.modalTransitionStyle = .crossDissolve
                
                vc.fruitType =  FruitsType.GUAVA
                self.present(vc, animated: true, completion: nil)
                
//                navigationController?.pushViewController(vc, animated: true)
        
        
//           }
        }
    
    @objc func imageTapped10(sender: UITapGestureRecognizer) {
//            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                
                vc.modalPresentationStyle = .fullScreen
        vc.modalTransitionStyle = .crossDissolve
                
                vc.fruitType =  FruitsType.WATERMELON
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
//           }
        }
    
    @objc func imageTapped11(sender: UITapGestureRecognizer) {
//            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                
               
                vc.modalPresentationStyle = .fullScreen
        vc.modalTransitionStyle = .crossDissolve
                vc.fruitType =  FruitsType.GRAPE
                self.present(vc, animated: true, completion: nil)
                
//                navigationController?.pushViewController(vc, animated: true)
        
        
//           }
        }
    
    @objc func imageTapped12(sender: UITapGestureRecognizer) {
//            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                
               
                vc.modalPresentationStyle = .fullScreen
        vc.modalTransitionStyle = .crossDissolve
                vc.fruitType =  FruitsType.PINEAPPLE
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
//           }
        }
    
    @objc func imageTapped13(sender: UITapGestureRecognizer) {
//            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                
               
                vc.modalPresentationStyle = .fullScreen
        vc.modalTransitionStyle = .crossDissolve
                vc.fruitType =  FruitsType.LEMON
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
//           }
        }
    
    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)

        let vc = storyboard.instantiateViewController(withIdentifier: "CategoryKids") as! CategoryKidsViewController
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }

}
