//
//  SampleViewController.swift
//  kids
//
//  Created by CIPL0957 on 20/05/22.
//

import UIKit
import AVFoundation

enum ColorsType {
    case APPLECOLOR
    case BANANACOLOR
    case MANGOCOLOR
    case ORANGECOLOR
    case STRAWBERRYCOLOR
    case GUAVACOLOR
    case WATERMELONCOLOR
    case GRAPECOLOR
    case PINEAPPLECOLOR
    case LEMONCOLOR
    case TOMATOCOLOR
    case CARROTCOLOR
    case BRINJALCOLOR
    case POTATOCOLOR
    case CHILLICOLOR
    case PUMPKINCOLOR
    case CAULIFLOWERCOLOR
    case CABBAGECOLOR
    case CUCUMBERCOLOR
    case ONIONCOLOR
    case COWCOLOR
    case LIONCOLOR
    case DOGCOLOR
    case ELEPHANTCOLOR
    case BEARCOLOR
    case DEERCOLOR
    case TORTOISECOLOR
    case MONKEYCOLOR
    case BULLCOLOR
    case HORSECOLOR
    case CARCOLOR
    case TRAINCOLOR
    case LORRYCOLOR
    case HELICOPTERCOLOR
    case VANCOLOR
    case AUTOCOLOR
    case BUSCOLOR
    case BIKECOLOR
    case JCBCOLOR
    case BOATCOLOR
}


class RetryViewController: UIViewController {
    var appleType: ApplesType?
    var bananaType: BananasType?
    var mangoType: MangoesType?
    var orangeType: OrangesType?
    var strawberryType: StrawberriesType?
    var guavaType: GuavasType?
    var watermelonType: WatermelonsType?
    var grapeType: GrapesType?
    var pineappleType: PineapplesType?
    var lemonType: LemonsType?
    var tomatoType: TomatoesType?
    var carrotType: CarrotsType?
    var brinjalType: BrinjalsType?
    var potatoType: PotatoesType?
    var chilliType: ChilliesType?
    var pumpkinType: PumpkinsType?
    var cauliflowerType: CauliflowersType?
    var cabbageType: CabbagesType?
    var cucumberType: CucumbersType?
    var onionType: OnionsType?
    var cowType: CowsTypes?
    var lionType: LionsTypes?
    var dogType: DogsTypes?
    var elephantType: ElephantsTypes?
    var bearType: BearsTypes?
    var deerType: DeersTypes?
    var tortoiseType: TortoisesTypes?
    var monkeyType: MonkiesTypes?
    var bullType: BullsTypes?
    var horseType: HorsesTypes?
    var carType: CarsTypes?
    var trainType: TrainsTypes?
    var lorryType: LorriesTypes?
    var helicopterType: HelicoptersTypes?
    var vanType: VansTypes?
    var autoType: AutosTypes?
    var busType: BusesTypes?
    var bikeType: BikesTypes?
    var jcbType: JcbTypes?
    var boatType: BoatsTypes?
    var colorType: ColorsType?
    @IBOutlet weak var bottomImageView: UIImageView!
    
//    var player : AVAudioPlayer!
    var objPlayer: AVAudioPlayer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        view.backgroundColor = .lightText

        do {
               let imageData = try Data(contentsOf: Bundle.main.url(forResource: "motivated", withExtension: "gif")!)
               self.bottomImageView.image = UIImage.gif(data: imageData)
           } catch {
               print(error)
           }
        // Do any additional setup after loading the view.
//        let blurEffect = UIBlurEffect(style: .systemUltraThinMaterialDark)
//        let blurEffectView = UIVisualEffectView(effect: blurEffect)
//        blurEffectView.frame = self.view.frame
//        self.view.insertSubview(blurEffectView, at: 0)
        
        
//        retrySound()
        playAudioFile()
    }
    func playAudioFile() {
        guard let url = Bundle.main.url(forResource: "retry", withExtension: "m4a") else { return }

        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playback)
            try AVAudioSession.sharedInstance().setActive(true)

            // For iOS versions < 11
            objPlayer = try AVAudioPlayer(contentsOf: url)// AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3)

            guard let aPlayer = objPlayer else { return }
            aPlayer.play()

        } catch let error {
            print(error.localizedDescription)
        }
    }
    
//    func retrySound(){
//            if let sound = Bundle.main.url(forResource: "retry", withExtension: "m4a") {
//                do {
//                    print("hi")
//                    player = try AVAudioPlayer(contentsOf:sound)
//                    player.play()
//                }catch{
//                    print("not play")
//                }
//            }else{
//                print("......")
//            }
//        }
//
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    
    @IBAction func cancel(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func retry(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func home(_ sender: Any) {
        
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "CategoryKids") as! CategoryKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .fullScreen
      //  navigationController?.pushViewController(vc, animated: true)
        
        self.present(vc, animated: true, completion: nil)
    }
    
//    @IBAction func next(_ sender: Any) {
////       dismiss(animated: true, completion: nil)
//
////
//      //  navigationController?.pushViewController(vc, animated: true)
//
//       // self.present(vc, animated: true, completion: nil)
//
//        switch self.appleType {
//              case .APPLE1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//            print("Button Tapped")
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "AppleNumber2") as! Apple2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .APPLE2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//            let vc = storyboard.instantiateViewController(withIdentifier: "AppleNumber4") as! Apple4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .APPLE3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "AppleNumber5") as! Apple5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .APPLE4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
////            vc.finishColor = FinishColors.LEMONCOLORS
////            vc.finishNumber = FinishNumbers.APPLENUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.bananaType {
//              case .BANANA1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "BananaNumber2") as! Banana2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .BANANA2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BananaNumber3") as! Banana3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .BANANA3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BananaNumber5") as! Banana5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .BANANA4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.LEMONCOLORS
//            vc.finishNumber = FinishNumbers.BANANANUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.mangoType {
//              case .MANGO1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "MangoNumber4") as! Mango4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .MANGO2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "MangoNumber5") as! Mango5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .MANGO3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "MangoNumber3") as! Mango3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .MANGO4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.LEMONCOLORS
//            vc.finishNumber = FinishNumbers.MANGONUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.orangeType {
//              case .ORANGE1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "OrangeNumber2") as! Orange2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .ORANGE2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "OrangeNumber4") as! Orange4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .ORANGE3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "OrangeNumber3") as! Orange3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .ORANGE4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.LEMONCOLORS
//            vc.finishNumber = FinishNumbers.ORANGENUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.strawberryType {
//        case .STRAWBERRY1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "StrawberryNumber5") as! Strawberry5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .STRAWBERRY2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "StrawberryNumber2") as! Strawberry2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .STRAWBERRY3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "StrawberryNumber4") as! Strawberry4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .STRAWBERRY4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.LEMONCOLORS
//            vc.finishNumber = FinishNumbers.STRAWBERRYNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.guavaType {
//              case .GUAVA1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "GuavaNumber2") as! Guava2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .GUAVA2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "GuavaNumber3") as! Guava3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .GUAVA3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "GuavaNumber5") as! Guava5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .GUAVA4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.LEMONCOLORS
//            vc.finishNumber = FinishNumbers.GUAVANUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.watermelonType {
//              case .WATERMELON1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "WatermelonNumber3") as! Watermelon3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .WATERMELON2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "WatermelonNumber4") as! Watermelon4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .WATERMELON3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "WatermelonNumber5") as! Watermelon5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .WATERMELON4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.LEMONCOLORS
//            vc.finishNumber = FinishNumbers.WATERMELONNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.grapeType {
//              case .GRAPE1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "GrapeNumber2") as! Grape2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .GRAPE2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "GrapeNumber3") as! Grape3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .GRAPE3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "GrapeNumber4") as! Grape4NUmberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .GRAPE4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.LEMONCOLORS
//            vc.finishNumber = FinishNumbers.GRAPENUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.pineappleType {
//              case .PINEAPPLE1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "PineappleNumber3") as! Pineapple3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .PINEAPPLE2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "PineappleNumber4") as! Pineapple4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .PINEAPPLE3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "PineappleNumber5") as! Pineapple5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .PINEAPPLE4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.LEMONCOLORS
//            vc.finishNumber = FinishNumbers.PINEAPPLENUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.lemonType {
//              case .LEMON1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "LemonNumber2") as! Lemon2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .LEMON2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "LemonNumber3") as! Lemon3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .LEMON3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "LemonNumber5") as! Lemon5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .LEMON4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.LEMONCOLORS
//            vc.finishNumber = FinishNumbers.LEMONNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//
//
//        switch self.tomatoType {
//              case .TOMATO1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "TomatoNumber2") as! Tomato2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .TOMATO2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "TomatoNumber4") as! Tomato4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .TOMATO3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "TomatoNumber5") as! Tomato5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .TOMATO4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.ONIONCOLORS
//            vc.finishNumber = FinishNumbers.TOMATONUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.carrotType {
//              case .CARROT1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "CarrotNumber2") as! Carrot2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .CARROT2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "CarrotNumber3") as! Carrot3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .CARROT3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "CarrotNumber5") as! Carrot5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .CARROT4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.ONIONCOLORS
//            vc.finishNumber = FinishNumbers.CARROTNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.brinjalType {
//              case .BRINJAL1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "BrinjalNumber2") as! Brinjal2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .BRINJAL2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BrinjalNumber3") as! Brinjal3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .BRINJAL3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BrinjalNumber4") as! Brinjal4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .BRINJAL4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.ONIONCOLORS
//            vc.finishNumber = FinishNumbers.BRINJALNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.potatoType {
//              case .POTATO1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "PotatoNumber4") as! Potato4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .POTATO2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "PotatoNumber5") as! Potato5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .POTATO3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "PotatoNumber3") as! Potato3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .POTATO4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.ONIONCOLORS
//            vc.finishNumber = FinishNumbers.POTATONUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.chilliType {
//        case .CHILLI1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "ChilliNumber2") as! Chilli2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .CHILLI2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "ChilliNumber4") as! Chilli4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .CHILLI3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "ChilliNumber5") as! Chilli5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .CHILLI4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.ONIONCOLORS
//            vc.finishNumber = FinishNumbers.CHILLINUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.pumpkinType {
//              case .PUMPKIN1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "PumpkinNumber2") as! Pumpkin2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .PUMPKIN2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "PumpkinNumber3") as! Pumpkin3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .PUMPKIN3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "PumpkinNumber4") as! Pumpkin4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .PUMPKIN4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.ONIONCOLORS
//            vc.finishNumber = FinishNumbers.PUMPKINNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.cauliflowerType {
//              case .CAULIFLOWER1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "CauliflowerNumber4") as! Cauliflower4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .CAULIFLOWER2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "CauliflowerNumber5") as! Cauliflower5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .CAULIFLOWER3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "CauliflowerNumber3") as! Cauliflower3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .CAULIFLOWER4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.ONIONCOLORS
//            vc.finishNumber = FinishNumbers.CAULIFLOWERNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.cabbageType {
//              case .CABBAGE1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "CabbageNumber2") as! Cabbage2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .CABBAGE2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "CabbageNumber3") as! Cabbage3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .CABBAGE3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "CabbageNumber5") as! Cabbage5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .CABBAGE4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.ONIONCOLORS
//            vc.finishNumber = FinishNumbers.CABBAGENUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.cucumberType {
//              case .CUCUMBER1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "CucumberNumber2") as! Cucumber2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .CUCUMBER2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "CucumberNumber4") as! Cucumber4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .CUCUMBER3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "CucumberNumber5") as! Cucumber5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .CUCUMBER4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.ONIONCOLORS
//            vc.finishNumber = FinishNumbers.CUCUMBERNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.onionType {
//              case .ONION1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "OnionNumber2") as! Onion2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .ONION2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "OnionNumber3") as! Onion3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .ONION3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "OnionNumber4") as! Onion4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .ONION4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.ONIONCOLORS
//            vc.finishNumber = FinishNumbers.ONIONNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//      //  navigationController?.pushViewController(vc, animated: true)
//
//       // self.present(vc, animated: true, completion: nil)
//
//        switch self.cowType {
//              case .COW1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "CowNumber2") as! Cow2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .COW2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "CowNumber3") as! Cow3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .COW3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "CowNumber5") as! Cow5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .COW4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.HORSECOLORS
//            vc.finishNumber = FinishNumbers.COWNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.lionType {
//              case .LION1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "LionNumber2") as! Lion2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .LION2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "LionNumber4") as! Lion4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .LION3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "LionNumber5") as! Lion5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .LION4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.HORSECOLORS
//            vc.finishNumber = FinishNumbers.LIONNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.dogType {
//              case .DOG1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "DogNumber2") as! Dog2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .DOG2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "DogNumber4") as! Dog4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .DOG3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "DogNumber5") as! Dog5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .DOG4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.HORSECOLORS
//            vc.finishNumber = FinishNumbers.DOGNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.elephantType {
//              case .ELEPHANT1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "ElephantNumber3") as! Elephant3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .ELEPHANT2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "ElephantNumber4") as! Elephant4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .ELEPHANT3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "ElephantNumber5") as! Elephant5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .ELEPHANT4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.HORSECOLORS
//            vc.finishNumber = FinishNumbers.ELEPHANTNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.bearType {
//        case .BEAR1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "BearNumber2") as! Bear2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .BEAR2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BearNumber3") as! Bear3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .BEAR3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BearNumber5") as! Bear5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .BEAR4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.HORSECOLORS
//            vc.finishNumber = FinishNumbers.BEARNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.deerType {
//              case .DEER1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "DeerNumber2") as! Deer2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .DEER2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "DeerNumber4") as! Deer4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .DEER3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "DeerNumber5") as! Deer5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .DEER4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.HORSECOLORS
//            vc.finishNumber = FinishNumbers.DEERNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.tortoiseType {
//              case .TORTOISE1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "TortoiseNumber4") as! Tortoise4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .TORTOISE2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "TortoiseNumber5") as! Tortoise5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .TORTOISE3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "TortoiseNumber3") as! Tortoise3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .TORTOISE4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.HORSECOLORS
//            vc.finishNumber = FinishNumbers.TORTOISENUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.monkeyType {
//              case .MONKEY1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "MonkeyNumber2") as! Monkey2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .MONKEY2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "MonkeyNumber3") as! Monkey3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .MONKEY3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "MonkeyNumber4") as! Monkey4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .MONKEY4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.HORSECOLORS
//            vc.finishNumber = FinishNumbers.MONKEYNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.bullType {
//              case .BULL1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "BullNumber3") as! Bull3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .BULL2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BullNumber4") as! Bull4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .BULL3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BullNumber5") as! Bull5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .BULL4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.HORSECOLORS
//            vc.finishNumber = FinishNumbers.BULLNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.horseType {
//              case .HORSE1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "HorseNumber2") as! Horse2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .HORSE2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "HorseNumber4") as! Horse4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .HORSE3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "HorseNumber5") as! Horse5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .HORSE4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.HORSECOLORS
//            vc.finishNumber = FinishNumbers.HORSENUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.carType {
//              case .CAR1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "CarNumber2") as! Car2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .CAR2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "CarNumber4") as! Car4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .CAR3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "CarNumber5") as! Car5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .CAR4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.BOATCOLORS
//            vc.finishNumber = FinishNumbers.CARNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.trainType {
//              case .TRAIN1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "TrainNumber3") as! Train3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                            navigationController?.pushViewController(vc, animated: true)
//        case  .TRAIN2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "TrainNumber4") as! Train4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .TRAIN3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "TrainNumber5") as! Train5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .TRAIN4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.BOATCOLORS
//            vc.finishNumber = FinishNumbers.TRAINNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.lorryType {
//              case .LORRY1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "LorryNumber3") as! Lorry3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .LORRY2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "LorryNumber4") as! Lorry4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .LORRY3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "LorryNumber5") as! Lorry5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .LORRY4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.BOATCOLORS
//            vc.finishNumber = FinishNumbers.LORRYNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.helicopterType {
//              case .HELICOPTER1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "HelicopterNumber2") as! Helicopter2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                            navigationController?.pushViewController(vc, animated: true)
//        case  .HELICOPTER2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "HelicopterNumber3") as! Helicopter3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .HELICOPTER3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "HelicopterNumber4") as! Helicopter4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .HELICOPTER4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.BOATCOLORS
//            vc.finishNumber = FinishNumbers.HELICOPTERNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.vanType {
//        case .VAN1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "VanNumber2") as! Van2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .VAN2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "VanNumber4") as! Van4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .VAN3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "VanNumber5") as! Van5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .VAN4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.BOATCOLORS
//            vc.finishNumber = FinishNumbers.VANNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.autoType {
//              case .AUTO1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "AutoNumber3") as! Auto3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .AUTO2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "AutoNumber4") as! Auto4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .AUTO3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "AutoNumber5") as! Auto5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .AUTO4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.BOATCOLORS
//            vc.finishNumber = FinishNumbers.AUTONUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.busType {
//              case .BUS1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "BusNumber2") as! Bus2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .BUS2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BusNumber4") as! Bus4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .BUS3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BusNumber6") as! Bus6NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .BUS4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.BOATCOLORS
//            vc.finishNumber = FinishNumbers.BUSNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.bikeType {
//              case .BIKE1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "BikeNumber2") as! Bike2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .BIKE2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BikeNumber3") as! Bike3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .BIKE3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BikeNumber4") as! Bike4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .BIKE4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.BOATCOLORS
//            vc.finishNumber = FinishNumbers.BIKENUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//        switch self.jcbType {
//              case .JCB1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "JcbNumber3") as! Jcb3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .JCB2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "JcbNumber4") as! Jcb4NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .JCB3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "JcbNumber5") as! Jcb5NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .JCB4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.BOATCOLORS
//            vc.finishNumber = FinishNumbers.JCBNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//        switch self.boatType {
//              case .BOAT1:
//                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                   let vc = storyboard.instantiateViewController(withIdentifier: "BoatNumber2") as! Boat2NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
//        case  .BOAT2:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BoatNumber3") as! Boat3NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//        case .BOAT3:
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "BoatNumber6") as! Boat6NumberViewController
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//        case .BOAT4:
//
//            let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.finishColor = FinishColors.BOATCOLORS
//            vc.finishNumber = FinishNumbers.BOATNUMBERS
//            vc.modalPresentationStyle = .fullScreen
//            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//        default: break
//          }
//
//      switch self.colorType {
//            case .APPLECOLOR:
//                 let storyboard = UIStoryboard(name: "Main", bundle: nil)
//          print("Button Tapped")
//
//                 let vc = storyboard.instantiateViewController(withIdentifier: "BananaColor") as! BananaColorViewController
//          vc.modalPresentationStyle = .fullScreen
//          self.present(vc, animated: true, completion: nil)
//                          navigationController?.pushViewController(vc, animated: true)
//      case  .BANANACOLOR:
//
//          let storyboard = UIStoryboard(name: "Main", bundle: nil)
//          let vc = storyboard.instantiateViewController(withIdentifier: "MangoColor") as! MangoColorViewController
//          vc.modalPresentationStyle = .fullScreen
//          self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//      case .MANGOCOLOR:
//          let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//          let vc = storyboard.instantiateViewController(withIdentifier: "OrangeColor") as! OrangeColorViewController
//          vc.modalPresentationStyle = .fullScreen
//          self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//      case .ORANGECOLOR:
//
//          let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//          let vc = storyboard.instantiateViewController(withIdentifier: "StrawberryColor") as! StrawberryColorViewController
//          vc.modalPresentationStyle = .fullScreen
//          self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//      case .STRAWBERRYCOLOR:
//           let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    print("Button Tapped")
//
//           let vc = storyboard.instantiateViewController(withIdentifier: "GuavaColor") as! GuavaColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
//case  .GUAVACOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    let vc = storyboard.instantiateViewController(withIdentifier: "WatermelonColor") as! WatermelonColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//case .WATERMELONCOLOR:
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "GrapeColor") as! GrapeColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//case .GRAPECOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "PineappleColor") as! PineappleColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
//
//      case .PINEAPPLECOLOR:
//           let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    print("Button Tapped")
//
//           let vc = storyboard.instantiateViewController(withIdentifier: "LemonColor") as! LemonColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
//case  .LEMONCOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//          vc.finishColor = FinishColors.LEMONCOLORS
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//case .TOMATOCOLOR:
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "CarrotColor") as! CarrotColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//case .CARROTCOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "BrinjalColor") as! BrinjalColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
//
//case  .BRINJALCOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    let vc = storyboard.instantiateViewController(withIdentifier: "PotatoColor") as! PotatoColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//case .POTATOCOLOR:
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "ChilliColor") as! ChilliColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//case .CHILLICOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "PumpkinColor") as! PumpkinColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
//
//      case .PUMPKINCOLOR:
//           let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    print("Button Tapped")
//
//           let vc = storyboard.instantiateViewController(withIdentifier: "CauliflowerColor") as! CauliflowerColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
//case  .CAULIFLOWERCOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    let vc = storyboard.instantiateViewController(withIdentifier: "CabbageColor") as! CabbageColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//case .CABBAGECOLOR:
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "CucumberColor") as! CucumberColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//case .CUCUMBERCOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "OnionColor") as! OnionColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
//
//
//case  .ONIONCOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//          vc.finishColor = FinishColors.ONIONCOLORS
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//case .COWCOLOR:
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "LionColor") as! LionColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//case .LIONCOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "DogColor") as! DogColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
//
//      case .DOGCOLOR:
//           let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    print("Button Tapped")
//
//           let vc = storyboard.instantiateViewController(withIdentifier: "ElephantColor") as! ElephantColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
//case  .ELEPHANTCOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    let vc = storyboard.instantiateViewController(withIdentifier: "BearColor") as! BearColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//case .BEARCOLOR:
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "DeerColor") as! DeerColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//case .DEERCOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "TortoiseColor") as! TortoiseColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
//
//case .TORTOISECOLOR:
//           let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    print("Button Tapped")
//
//           let vc = storyboard.instantiateViewController(withIdentifier: "MonkeyColor") as! MonkeyColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
//case  .MONKEYCOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    let vc = storyboard.instantiateViewController(withIdentifier: "BullColor") as! BullColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//case .BULLCOLOR:
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "HorseColor") as! HorseColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//case .HORSECOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//          vc.finishColor = FinishColors.HORSECOLORS
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
//
//
//case .CARCOLOR:
//           let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    print("Button Tapped")
//
//           let vc = storyboard.instantiateViewController(withIdentifier: "TrainColor") as! TrainColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
//case  .TRAINCOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//    let vc = storyboard.instantiateViewController(withIdentifier: "LorryColor") as! LorryColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//case .LORRYCOLOR:
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "HelicopterColor") as! HelicopterColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//case .HELICOPTERCOLOR:
//
//    let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//    let vc = storyboard.instantiateViewController(withIdentifier: "VanColor") as! VanColorViewController
//    vc.modalPresentationStyle = .fullScreen
//    self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//case .VANCOLOR:
//     let storyboard = UIStoryboard(name: "Main", bundle: nil)
//print("Button Tapped")
//
//     let vc = storyboard.instantiateViewController(withIdentifier: "AutoColor") as! AutoColorViewController
//vc.modalPresentationStyle = .fullScreen
//self.present(vc, animated: true, completion: nil)
//              navigationController?.pushViewController(vc, animated: true)
//case  .AUTOCOLOR:
//
//let storyboard = UIStoryboard(name: "Main", bundle: nil)
//let vc = storyboard.instantiateViewController(withIdentifier: "BusColor") as! BusColorViewController
//vc.modalPresentationStyle = .fullScreen
//self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//
//case .BUSCOLOR:
//let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//let vc = storyboard.instantiateViewController(withIdentifier: "BikeColor") as! BikeColorViewController
//vc.modalPresentationStyle = .fullScreen
//self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//
//case .BIKECOLOR:
//
//let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//let vc = storyboard.instantiateViewController(withIdentifier: "JcbColor") as! JcbColorViewController
//vc.modalPresentationStyle = .fullScreen
//self.present(vc, animated: true, completion: nil)
//
//case .JCBCOLOR:
//     let storyboard = UIStoryboard(name: "Main", bundle: nil)
//print("Button Tapped")
//
//     let vc = storyboard.instantiateViewController(withIdentifier: "BoatColor") as! BoatColorViewController
//vc.modalPresentationStyle = .fullScreen
//self.present(vc, animated: true, completion: nil)
//              navigationController?.pushViewController(vc, animated: true)
//case  .BOATCOLOR:
//
//let storyboard = UIStoryboard(name: "Main", bundle: nil)
//let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//          vc.finishColor = FinishColors.BOATCOLORS
//vc.modalPresentationStyle = .fullScreen
//self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
//      default: break
//        }
//
//    }
}
