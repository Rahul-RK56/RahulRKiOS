//
//  CarrotColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 23/05/22.
//

import UIKit

class CarrotColorViewController: UIViewController {
    
    @IBOutlet weak var optionOrange5: UIImageView!
    
    @IBOutlet weak var optionRed5: UIImageView!
    
    @IBOutlet weak var optionGreen5: UIImageView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA12 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionOrange5))
        optionOrange5.addGestureRecognizer(optionA12)
        optionOrange5.isUserInteractionEnabled = true
        
        let optionB12 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionRed5))
        optionRed5.addGestureRecognizer(optionB12)
        optionRed5.isUserInteractionEnabled = true
        
        let optionC12 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionGreen5))
        optionGreen5.addGestureRecognizer(optionC12)
        optionGreen5.isUserInteractionEnabled = true
    }
    
    
    @objc func imageTappedOptionOrange5(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.CARROTCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionRed5(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.CARROTCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionGreen5(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.CARROTCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vegetableType =  VegetablesType.CARROT
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
}
