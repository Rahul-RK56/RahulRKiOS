//
//  JcbColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class JcbColorViewController: UIViewController {
    @IBOutlet weak var jcbOptionBrown: UIImageView!
    @IBOutlet weak var jcbOptionOrange: UIImageView!
    @IBOutlet weak var jcbOptionYellow: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA37 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBrown20))
        jcbOptionBrown.addGestureRecognizer(optionA37)
        jcbOptionBrown.isUserInteractionEnabled = true
        
        let optionB37 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionOrange20))
        jcbOptionOrange.addGestureRecognizer(optionB37)
        jcbOptionOrange.isUserInteractionEnabled = true
        
        let optionC37 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionYellow20))
        jcbOptionYellow.addGestureRecognizer(optionC37)
        jcbOptionYellow.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionBrown20(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
//                vc.modalTransitionStyle = .partialCurl
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.JCBCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionOrange20(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
//                vc.modalTransitionStyle = .partialCurl
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.JCBCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionYellow20(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
//                vc.modalTransitionStyle = .partialCurl
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.JCBCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vehicleType =  VehiclesType.JCB
        self.present(vc, animated: true, completion: nil)
    }
    
}
