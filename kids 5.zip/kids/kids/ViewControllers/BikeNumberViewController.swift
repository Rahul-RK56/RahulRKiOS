//
//  BikeNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class BikeNumberViewController: UIViewController {
    @IBOutlet weak var bikeOption2: UIImageView!
    @IBOutlet weak var bikeOption4: UIImageView!
    @IBOutlet weak var bikeOption5: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA35 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption217))
        bikeOption2.addGestureRecognizer(optionA35)
        bikeOption2.isUserInteractionEnabled = true
        
        let optionB35 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption417))
        bikeOption4.addGestureRecognizer(optionB35)
        bikeOption4.isUserInteractionEnabled = true
        
        let optionC35 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption517))
        bikeOption5.addGestureRecognizer(optionC35)
        bikeOption5.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption217(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.bikeType = .BIKE1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption417(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.bikeType = .BIKE1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption517(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.bikeType = .BIKE1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vehicleType =  VehiclesType.BIKE
        self.present(vc, animated: true, completion: nil)

    }
}
