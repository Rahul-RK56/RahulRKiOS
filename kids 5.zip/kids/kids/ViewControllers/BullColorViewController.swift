//
//  BullColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class BullColorViewController: UIViewController {
    
    @IBOutlet weak var bullOptionBrown: UIImageView!
    
    @IBOutlet weak var bullOptionBlack: UIImageView!
    
    @IBOutlet weak var bullOptionYellow: UIImageView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA29 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBrown16))
        bullOptionBrown.addGestureRecognizer(optionA29)
        bullOptionBrown.isUserInteractionEnabled = true
        
        let optionB29 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlack16))
        bullOptionBlack.addGestureRecognizer(optionB29)
        bullOptionBlack.isUserInteractionEnabled = true
        
        let optionC29 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionYellow16))
        bullOptionYellow.addGestureRecognizer(optionC29)
        bullOptionYellow.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionBrown16(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.BULLCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionBlack16(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.BULLCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionYellow16(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.BULLCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.BULL
        self.present(vc, animated: true, completion: nil)
    }
}
