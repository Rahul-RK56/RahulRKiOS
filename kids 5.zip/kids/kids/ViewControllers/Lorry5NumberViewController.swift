//
//  Lorry5NumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 24/06/22.
//

import UIKit

class Lorry5NumberViewController: UIViewController {
    
    @IBOutlet weak var lorryOption2: UIImageView!
    
    @IBOutlet weak var lorryOption4: UIImageView!
    
    @IBOutlet weak var lorryOption5: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let optionA25 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption310))
        lorryOption5.addGestureRecognizer(optionA25)
        lorryOption5.isUserInteractionEnabled = true
        
        let optionB25 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption410))
        lorryOption4.addGestureRecognizer(optionB25)
        lorryOption4.isUserInteractionEnabled = true
        
        let optionC25 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption510))
        lorryOption2.addGestureRecognizer(optionC25)
        lorryOption2.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption310(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.finishColor = FinishColors.BOATCOLORS
                vc.finishNumber = FinishNumbers.CARNUMBERS
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption410(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                

                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.lorryType = .LORRY4
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption510(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.lorryType = .LORRY4

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)

    }
    @IBAction func backButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vehicleType =  VehiclesType.LORRY
        self.present(vc, animated: true, completion: nil)
    }
    
}
