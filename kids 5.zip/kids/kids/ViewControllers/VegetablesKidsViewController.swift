//
//  VegetablesKidsViewController.swift
//  kids
//
//  Created by CIPL0957 on 17/05/22.
//

import UIKit

class VegetablesKidsViewController: UIViewController {

    @IBOutlet weak var tomatoImage: UIImageView!
    
    @IBOutlet weak var carrotImage: UIImageView!
    
    @IBOutlet weak var BrinjalImage: UIImageView!
    
    @IBOutlet weak var potatoImage: UIImageView!
    
    @IBOutlet weak var chilliImage: UIImageView!
    
    @IBOutlet weak var pumpkin: UIImageView!
    
    @IBOutlet weak var cauliflowerImage: UIImageView!
    
    @IBOutlet weak var cabbageImage: UIImageView!
    
    @IBOutlet weak var cucumberImage: UIImageView!
    
    @IBOutlet weak var onionImage: UIImageView!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let tapGR8 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped8))
        tomatoImage.addGestureRecognizer(tapGR8)
        tomatoImage.isUserInteractionEnabled = true
        
        
        
        
        let tapGR9 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped9))
        carrotImage.addGestureRecognizer(tapGR9)
        carrotImage.isUserInteractionEnabled = true
        
        
        
        let tapGR10 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped10))
        BrinjalImage.addGestureRecognizer(tapGR10)
        BrinjalImage.isUserInteractionEnabled = true
        
        
        
        
        let tapGR11 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped11))
        potatoImage.addGestureRecognizer(tapGR11)
        potatoImage.isUserInteractionEnabled = true
        
        let tapGR12 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped12))
        chilliImage.addGestureRecognizer(tapGR12)
        chilliImage.isUserInteractionEnabled = true
        
        let tapGR13 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped13))
        pumpkin.addGestureRecognizer(tapGR13)
        pumpkin.isUserInteractionEnabled = true
        
        let tapGR14 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped14))
        cauliflowerImage.addGestureRecognizer(tapGR14)
        cauliflowerImage.isUserInteractionEnabled = true
        
        let tapGR15 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped15))
        cabbageImage.addGestureRecognizer(tapGR15)
        cabbageImage.isUserInteractionEnabled = true
        
        let tapGR16 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped16))
        cucumberImage.addGestureRecognizer(tapGR16)
        cucumberImage.isUserInteractionEnabled = true
        
        let tapGR17 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped17))
        onionImage.addGestureRecognizer(tapGR17)
        onionImage.isUserInteractionEnabled = true
        
    }
    @objc func imageTapped8(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
                vc.modalTransitionStyle = .crossDissolve
                vc.vegetableType = VegetablesType.TOMATO
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped9(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
                vc.modalTransitionStyle = .crossDissolve
                vc.vegetableType = VegetablesType.CARROT
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped10(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
                vc.modalTransitionStyle = .crossDissolve
                vc.vegetableType = VegetablesType.BRINJAL
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped11(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
                vc.modalTransitionStyle = .crossDissolve
                vc.vegetableType = VegetablesType.POTATO
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped12(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
                vc.modalTransitionStyle = .crossDissolve
                vc.vegetableType = VegetablesType.CHILLI
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped13(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
                vc.modalTransitionStyle = .crossDissolve
                vc.vegetableType = VegetablesType.PUMPKIN
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped14(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
                vc.modalTransitionStyle = .crossDissolve
                vc.vegetableType = VegetablesType.CAULIFLOWER
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped15(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
                vc.modalTransitionStyle = .crossDissolve
                vc.vegetableType = VegetablesType.CABBAGE
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped16(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
                vc.modalTransitionStyle = .crossDissolve
                vc.vegetableType = VegetablesType.CUCUMBER
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped17(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalPresentationStyle = .fullScreen
                vc.modalTransitionStyle = .crossDissolve
                vc.vegetableType = VegetablesType.ONION
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }

    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "CategoryKids") as! CategoryKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func menuButton(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }

}
