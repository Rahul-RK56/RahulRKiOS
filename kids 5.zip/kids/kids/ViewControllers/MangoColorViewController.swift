//
//  MangoColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 20/05/22.
//

import UIKit

class MangoColorViewController: UIViewController {
    
    
    @IBOutlet weak var optionBlue2: UIImageView!
    
    @IBOutlet weak var optionYellow2: UIImageView!
    
    @IBOutlet weak var optionGreen2: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA6 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlue2))
        optionBlue2.addGestureRecognizer(optionA6)
        optionBlue2.isUserInteractionEnabled = true
        
        let optionB6 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionYellow2))
        optionYellow2.addGestureRecognizer(optionB6)
        optionYellow2.isUserInteractionEnabled = true
        
        let optionC6 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionGreen2))
        optionGreen2.addGestureRecognizer(optionC6)
        optionGreen2.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionBlue2(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.MANGOCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionYellow2(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.MANGOCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionGreen2(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.MANGOCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        vc.fruitType =  FruitsType.MANGO
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
}
