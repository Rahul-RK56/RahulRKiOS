//
//  AnimalsKidsViewController.swift
//  kids
//
//  Created by CIPL0957 on 17/05/22.
//

import UIKit

class AnimalsKidsViewController: UIViewController {

    @IBOutlet weak var cowImage: UIImageView!
    
    @IBOutlet weak var lionImage: UIImageView!
    
    @IBOutlet weak var dogImage: UIImageView!
    
    @IBOutlet weak var elephantImage: UIImageView!
    
    @IBOutlet weak var bearImage: UIImageView!
    
    @IBOutlet weak var deerImage: UIImageView!
    
    @IBOutlet weak var tortoiseImage: UIImageView!
    
    @IBOutlet weak var monkeyImage: UIImageView!
    
    @IBOutlet weak var bullImage: UIImageView!
    
    @IBOutlet weak var horseImage: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let tapGR12 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped12))
        cowImage.addGestureRecognizer(tapGR12)
        cowImage.isUserInteractionEnabled = true
        
        
        
        let tapGR13 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped13))
        lionImage.addGestureRecognizer(tapGR13)
        lionImage.isUserInteractionEnabled = true
        
        
        let tapGR14 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped14))
        dogImage.addGestureRecognizer(tapGR14)
        dogImage.isUserInteractionEnabled = true
        
        
        
        let tapGR15 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped15))
        elephantImage.addGestureRecognizer(tapGR15)
        elephantImage.isUserInteractionEnabled = true
        
        let tapGR16 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped16))
        bearImage.addGestureRecognizer(tapGR16)
        bearImage.isUserInteractionEnabled = true
        
        let tapGR17 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped17))
        deerImage.addGestureRecognizer(tapGR17)
        deerImage.isUserInteractionEnabled = true
        
        let tapGR18 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped18))
        tortoiseImage.addGestureRecognizer(tapGR18)
        tortoiseImage.isUserInteractionEnabled = true
        
        let tapGR19 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped19))
        monkeyImage.addGestureRecognizer(tapGR19)
        monkeyImage.isUserInteractionEnabled = true
        
        let tapGR20 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped20))
        bullImage.addGestureRecognizer(tapGR20)
        bullImage.isUserInteractionEnabled = true
        
        let tapGR21 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped21))
        horseImage.addGestureRecognizer(tapGR21)
        horseImage.isUserInteractionEnabled = true
    }
    @objc func imageTapped12(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.animalType = AnimalsType.COW
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }

    @objc func imageTapped13(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.animalType = AnimalsType.LION
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    @objc func imageTapped14(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.animalType = AnimalsType.DOG
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    @objc func imageTapped15(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.animalType = AnimalsType.ELEPHANT
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped16(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.animalType = AnimalsType.BEAR
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped17(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.animalType = AnimalsType.DEER
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped18(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.animalType = AnimalsType.TORTOISE
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped19(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.animalType = AnimalsType.MONKEY
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped20(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.animalType = AnimalsType.BULL
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped21(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.animalType = AnimalsType.HORSE
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }

    
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "CategoryKids") as! CategoryKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }

}
