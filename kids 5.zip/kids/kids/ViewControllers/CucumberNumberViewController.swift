//
//  CucumberNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 10/06/22.
//

import UIKit

class CucumberNumberViewController: UIViewController {
    @IBOutlet weak var cucumberOption3: UIImageView!
    @IBOutlet weak var cucumberOption4: UIImageView!
    @IBOutlet weak var cucumberOption5: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA20 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption40))
        cucumberOption3.addGestureRecognizer(optionA20)
        cucumberOption3.isUserInteractionEnabled = true
        
        let optionB20 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption50))
        cucumberOption4.addGestureRecognizer(optionB20)
        cucumberOption4.isUserInteractionEnabled = true
        
        let optionC20 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption60))
        cucumberOption5.addGestureRecognizer(optionC20)
        cucumberOption5.isUserInteractionEnabled = true
    }
    @objc func imageTappedOption40(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.cucumberType = .CUCUMBER1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption50(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.cucumberType = .CUCUMBER1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption60(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.cucumberType = .CUCUMBER1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backBUtton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vegetableType =  VegetablesType.CUCUMBER
        self.present(vc, animated: true, completion: nil)
    }
}
