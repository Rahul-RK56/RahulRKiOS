//
//  DeerNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class DeerNumberViewController: UIViewController {
    
    @IBOutlet weak var DeerOption3: UIImageView!
    
    @IBOutlet weak var DeerOption4: UIImageView!
    
    @IBOutlet weak var DeerOption5: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let optionA25 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption31))
        DeerOption3.addGestureRecognizer(optionA25)
        DeerOption3.isUserInteractionEnabled = true
        
        let optionB25 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption41))
        DeerOption4.addGestureRecognizer(optionB25)
        DeerOption4.isUserInteractionEnabled = true
        
        let optionC25 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption51))
        DeerOption5.addGestureRecognizer(optionC25)
        DeerOption5.isUserInteractionEnabled = true
    }
    @objc func imageTappedOption31(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.deerType = .DEER1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption41(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.deerType = .DEER1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption51(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.deerType = .DEER1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.DEER
        self.present(vc, animated: true, completion: nil)
    }
}
