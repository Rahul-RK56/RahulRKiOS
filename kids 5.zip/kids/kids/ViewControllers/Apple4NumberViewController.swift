//
//  Apple4NumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 20/06/22.
//

import UIKit

class Apple4NumberViewController: UIViewController {
    
    @IBOutlet weak var AppleOption3: UIImageView!
    
    @IBOutlet weak var AppleOption4: UIImageView!
    
    @IBOutlet weak var AppleOption5: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let optionA1 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption3))
        AppleOption3.addGestureRecognizer(optionA1)
        AppleOption3.isUserInteractionEnabled = true
        
        let optionB1 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption4))
        AppleOption4.addGestureRecognizer(optionB1)
        AppleOption4.isUserInteractionEnabled = true
        
        let optionC1 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption5))
        AppleOption5.addGestureRecognizer(optionC1)
        AppleOption5.isUserInteractionEnabled = true
    }
    @objc func imageTappedOption3(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                
                vc.appleType =  ApplesType.APPLE3

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption4(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.appleType =  ApplesType.APPLE3
//
                
                self.present(vc, animated: true, completion: nil)
        
        
           }
        }
    
    @objc func imageTappedOption5(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.appleType =  ApplesType.APPLE3

//                vc.vehicleType = VehiclesType.CAR
                self.present(vc, animated: true, completion: nil)
        
        
           }
        }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: Any) {
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        vc.fruitType =  FruitsType.APPLE
        self.present(vc, animated: true, completion: nil)
        
    }
}
