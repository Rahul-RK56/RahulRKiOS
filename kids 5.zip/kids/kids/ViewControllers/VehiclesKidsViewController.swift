//
//  VehiclesKidsViewController.swift
//  kids
//
//  Created by CIPL0957 on 17/05/22.
//

import UIKit

class VehiclesKidsViewController: UIViewController {
    
    
    @IBOutlet weak var carImage: UIImageView!
    
    @IBOutlet weak var trainImage: UIImageView!
    
    @IBOutlet weak var lorryImage: UIImageView!

    @IBOutlet weak var helihopterImage: UIImageView!
    
    @IBOutlet weak var vanImage: UIImageView!
    
    @IBOutlet weak var autoImage: UIImageView!
    
    @IBOutlet weak var busImage: UIImageView!
    
    @IBOutlet weak var bikeImage: UIImageView!
    
    @IBOutlet weak var jcbImage: UIImageView!
    
    @IBOutlet weak var boatImage: UIImageView!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let tapGR16 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped16))
        carImage.addGestureRecognizer(tapGR16)
        carImage.isUserInteractionEnabled = true
        
        
        
        
        let tapGR17 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped17))
        trainImage.addGestureRecognizer(tapGR17)
        trainImage.isUserInteractionEnabled = true
        
        
        
        let tapGR18 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped18))
        lorryImage.addGestureRecognizer(tapGR18)
        lorryImage.isUserInteractionEnabled = true
        
        
        
        let tapGR19 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped19))
        helihopterImage.addGestureRecognizer(tapGR19)
        helihopterImage.isUserInteractionEnabled = true
        
        let tapGR20 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped20))
        vanImage.addGestureRecognizer(tapGR20)
        vanImage.isUserInteractionEnabled = true
        
        let tapGR21 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped21))
        autoImage.addGestureRecognizer(tapGR21)
        autoImage.isUserInteractionEnabled = true
        
        let tapGR22 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped22))
        busImage.addGestureRecognizer(tapGR22)
        busImage.isUserInteractionEnabled = true
        
        let tapGR23 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped23))
        bikeImage.addGestureRecognizer(tapGR23)
        bikeImage.isUserInteractionEnabled = true
        
        let tapGR24 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped24))
        jcbImage.addGestureRecognizer(tapGR24)
        jcbImage.isUserInteractionEnabled = true
        
        let tapGR25 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped25))
        boatImage.addGestureRecognizer(tapGR25)
        boatImage.isUserInteractionEnabled = true
        
        
    }
    
    @objc func imageTapped16(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.vehicleType = VehiclesType.CAR
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped17(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.vehicleType = VehiclesType.TRAIN
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped18(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.vehicleType = VehiclesType.LORRY
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped19(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.vehicleType = VehiclesType.HELICOPTER
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped20(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.vehicleType = VehiclesType.VAN
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped21(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.vehicleType = VehiclesType.AUTO
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped22(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.vehicleType = VehiclesType.BUS
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped23(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.vehicleType = VehiclesType.BIKE
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped24(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.vehicleType = VehiclesType.JCB
                self.present(vc, animated: true, completion: nil)
//                navigationController?.pushViewController(vc, animated: true)
        
        
           }
        }
    
    @objc func imageTapped25(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
                vc.modalTransitionStyle = .crossDissolve
                vc.modalPresentationStyle = .fullScreen
                vc.vehicleType = VehiclesType.BOAT
                
//                navigationController?.pushViewController(vc, animated: true)
                self.present(vc, animated: true, completion: nil)
        
        
           }
        }
    
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "CategoryKids") as! CategoryKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
}
