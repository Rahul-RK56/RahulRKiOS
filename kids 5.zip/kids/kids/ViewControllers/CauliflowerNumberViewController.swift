//
//  CauliflowerNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 10/06/22.
//

import UIKit

class CauliflowerNumberViewController: UIViewController {
    @IBOutlet weak var cauliflowerOption3: UIImageView!
    @IBOutlet weak var cauliflowerOption2: UIImageView!
    @IBOutlet weak var cauliflowerOption5: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let optionA18 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption38))
        cauliflowerOption3.addGestureRecognizer(optionA18)
        cauliflowerOption3.isUserInteractionEnabled = true
        
        let optionB18 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption48))
        cauliflowerOption2.addGestureRecognizer(optionB18)
        cauliflowerOption2.isUserInteractionEnabled = true
        
        let optionC18 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption58))
        cauliflowerOption5.addGestureRecognizer(optionC18)
        cauliflowerOption5.isUserInteractionEnabled = true
    }
    @objc func imageTappedOption38(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.cauliflowerType = .CAULIFLOWER1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption48(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.cauliflowerType = .CAULIFLOWER1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption58(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.cauliflowerType = .CAULIFLOWER1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vegetableType =  VegetablesType.CAULIFLOWER
        self.present(vc, animated: true, completion: nil)
    }
    
}
