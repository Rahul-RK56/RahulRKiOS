//
//  DogNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 24/05/22.
//

import UIKit

class DogNumberViewController: UIViewController {
    
    @IBOutlet weak var option38: UIImageView!
    
    @IBOutlet weak var option48: UIImageView!
    
    @IBOutlet weak var option58: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA21 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption38))
        option38.addGestureRecognizer(optionA21)
        option38.isUserInteractionEnabled = true
        
        
        let optionB21 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption48))
        option48.addGestureRecognizer(optionB21)
        option48.isUserInteractionEnabled = true
        
        let optionC21 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption58))
        option58.addGestureRecognizer(optionC21)
        option58.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption38(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.dogType = .DOG1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption48(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.dogType = .DOG1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption58(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.dogType = .DOG1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.DOG
        self.present(vc, animated: true, completion: nil)

    }
    @IBAction func menuButton(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
}
