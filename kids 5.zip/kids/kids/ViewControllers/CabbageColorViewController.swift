//
//  CabbageColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 10/06/22.
//

import UIKit

class CabbageColorViewController: UIViewController {
    @IBOutlet weak var cabbageOptionOrange: UIImageView!
    @IBOutlet weak var cabbageOptionRed: UIImageView!
    @IBOutlet weak var cabbageOptionGreen: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA20 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionOrange11))
        cabbageOptionOrange.addGestureRecognizer(optionA20)
        cabbageOptionOrange.isUserInteractionEnabled = true
        
        let optionB20 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionRed11))
        cabbageOptionRed.addGestureRecognizer(optionB20)
        cabbageOptionRed.isUserInteractionEnabled = true
        
        let optionC20 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionGreen11))
        cabbageOptionGreen.addGestureRecognizer(optionC20)
        cabbageOptionGreen.isUserInteractionEnabled = true
    }
    @objc func imageTappedOptionOrange11(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.CABBAGECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionRed11(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.CABBAGECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionGreen11(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.CABBAGECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vegetableType =  VegetablesType.CABBAGE
        self.present(vc, animated: true, completion: nil)
    }
    
}
