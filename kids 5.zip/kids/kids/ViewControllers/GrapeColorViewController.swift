//
//  GrapeColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 10/06/22.
//

import UIKit

class GrapeColorViewController: UIViewController {
    
    @IBOutlet weak var grapeOptionBlue: UIImageView!
    
    @IBOutlet weak var grapeOptionPurple: UIImageView!
    
    @IBOutlet weak var grapeOptionYellow: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA12 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlue7))
        grapeOptionBlue.addGestureRecognizer(optionA12)
        grapeOptionBlue.isUserInteractionEnabled = true
        
        let optionB12 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionPurple7))
        grapeOptionPurple.addGestureRecognizer(optionB12)
        grapeOptionPurple.isUserInteractionEnabled = true
        
        let optionC12 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionYellow7))
        grapeOptionYellow.addGestureRecognizer(optionC12)
        grapeOptionYellow.isUserInteractionEnabled = true
    }
    @objc func imageTappedOptionBlue7(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.GRAPECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionPurple7(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.GRAPECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionYellow7(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.GRAPECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.fruitType =  FruitsType.GRAPE
        self.present(vc, animated: true, completion: nil)
    }
}
