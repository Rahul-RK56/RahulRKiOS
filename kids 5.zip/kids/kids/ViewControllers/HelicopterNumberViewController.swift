//
//  HelicopterNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 25/05/22.
//

import UIKit

class HelicopterNumberViewController: UIViewController {
    
    @IBOutlet weak var option213: UIImageView!
    
    @IBOutlet weak var option413: UIImageView!
    
    @IBOutlet weak var option513: UIImageView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA31 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption213))
        option513.addGestureRecognizer(optionA31)
        option513.isUserInteractionEnabled = true
        
        let optionB31 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption413))
        option413.addGestureRecognizer(optionB31)
        option413.isUserInteractionEnabled = true
        
        let optionC31 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption513))
        option213.addGestureRecognizer(optionC31)
        option213.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption213(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.helicopterType = .HELICOPTER1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption413(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.helicopterType = .HELICOPTER1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption513(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.helicopterType = .HELICOPTER1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vehicleType =  VehiclesType.HELICOPTER
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func menuButton(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
}
