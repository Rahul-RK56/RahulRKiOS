//
//  FinishViewController.swift
//  kids
//
//  Created by CIPL0957 on 30/06/22.


//
    
import UIKit
import AVFoundation

enum FinishColors {
    
    case LEMONCOLORS
    case ONIONCOLORS
    case HORSECOLORS
    case BOATCOLORS
}

enum FinishNumbers {
    case APPLENUMBERS
    case BANANANUMBERS
    case MANGONUMBERS
    case ORANGENUMBERS
    case STRAWBERRYNUMBERS
    case GUAVANUMBERS
    case WATERMELONNUMBERS
    case GRAPENUMBERS
    case PINEAPPLENUMBERS
    case LEMONNUMBERS
    case TOMATONUMBERS
    case CARROTNUMBERS
    case BRINJALNUMBERS
    case POTATONUMBERS
    case CHILLINUMBERS
    case PUMPKINNUMBERS
    case CAULIFLOWERNUMBERS
    case CABBAGENUMBERS
    case CUCUMBERNUMBERS
    case ONIONNUMBERS
    case COWNUMBERS
    case LIONNUMBERS
    case DOGNUMBERS
    case ELEPHANTNUMBERS
    case BEARNUMBERS
    case DEERNUMBERS
    case TORTOISENUMBERS
    case MONKEYNUMBERS
    case BULLNUMBERS
    case HORSENUMBERS
    case CARNUMBERS
    case TRAINNUMBERS
    case LORRYNUMBERS
    case HELICOPTERNUMBERS
    case VANNUMBERS
    case AUTONUMBERS
    case BUSNUMBERS
    case BIKENUMBERS
    case JCBNUMBERS
    case BOATNUMBERS
}
   

class FinishViewController: UIViewController {
    
    var finishColor: FinishColors?
    
    var finishNumber: FinishNumbers?
    
    var objPlayer: AVAudioPlayer?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        view.backgroundColor = .lightText
        playAudioFile()
    }
    
    func playAudioFile() {
        guard let url = Bundle.main.url(forResource: "success", withExtension: "m4a") else { return }

        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playback)
            try AVAudioSession.sharedInstance().setActive(true)

            // For iOS versions < 11
            objPlayer = try AVAudioPlayer(contentsOf: url)// AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3)

            guard let aPlayer = objPlayer else { return }
            aPlayer.play()

        } catch let error {
            print(error.localizedDescription)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func cancelButton(_ sender: Any) {
////        dismiss(animated: true)
////        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyboard.instantiateViewController(withIdentifier: "LemonColor") as! LemonColorViewController
//         vc.modalPresentationStyle = .fullScreen
//         self.present(vc, animated: true, completion: nil)
//                 navigationController?.pushViewController(vc, animated: true)
        switch self.finishNumber {
              case .APPLENUMBERS:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
            print("Button Tapped")

                   let vc = storyboard.instantiateViewController(withIdentifier: "AppleNumber5") as! Apple5NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .BANANANUMBERS:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "BananaNumber5") as! Banana5NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .MANGONUMBERS:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "MangoNumber3") as! Mango3NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
            
        case .ORANGENUMBERS:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "OrangeNumber3") as! Orange3NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
        case .STRAWBERRYNUMBERS:
             let storyboard = UIStoryboard(name: "Main", bundle: nil)
      print("Button Tapped")

             let vc = storyboard.instantiateViewController(withIdentifier: "StrawberryNumber4") as! Strawberry4NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
                      navigationController?.pushViewController(vc, animated: true)
  case  .GUAVANUMBERS:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "GuavaNumber5") as! Guava5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .WATERMELONNUMBERS:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "WatermelonNumber5") as! Watermelon5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
  case .GRAPENUMBERS:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "GrapeNumber4") as! Grape4NUmberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
            
        case .PINEAPPLENUMBERS:
             let storyboard = UIStoryboard(name: "Main", bundle: nil)
      print("Button Tapped")

             let vc = storyboard.instantiateViewController(withIdentifier: "PineappleNumber5") as! Pineapple5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
                      navigationController?.pushViewController(vc, animated: true)
  case  .LEMONNUMBERS:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "LemonNumber5") as! Lemon5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .TOMATONUMBERS:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "TomatoNumber5") as! Tomato5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
  case .CARROTNUMBERS:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "CarrotNumber5") as! Carrot5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
       
  case  .BRINJALNUMBERS:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "BrinjalNumber4") as! Brinjal4NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .POTATONUMBERS:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "PotatoNumber3") as! Potato3NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
  case .CHILLINUMBERS:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "ChilliNumber5") as! Chilli5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
            
        case .PUMPKINNUMBERS:
             let storyboard = UIStoryboard(name: "Main", bundle: nil)
      print("Button Tapped")

             let vc = storyboard.instantiateViewController(withIdentifier: "PumpkinNumber4") as! Pumpkin4NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
                      navigationController?.pushViewController(vc, animated: true)
  case  .CAULIFLOWERNUMBERS:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "CauliflowerNumber3") as! Cauliflower3NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .CABBAGENUMBERS:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "CabbageNumber5") as! Cabbage5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
  case .CUCUMBERNUMBERS:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "CucumberNumber5") as! Cucumber5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
            
        
  case  .ONIONNUMBERS:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "OnionNumber4") as! Onion4NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .COWNUMBERS:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "CowNumber5") as! Cow5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
  case .LIONNUMBERS:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "LionNumber5") as! Lion5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
            
        case .DOGNUMBERS:
             let storyboard = UIStoryboard(name: "Main", bundle: nil)
      print("Button Tapped")

             let vc = storyboard.instantiateViewController(withIdentifier: "DogNumber5") as! Dog5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
                      navigationController?.pushViewController(vc, animated: true)
  case  .ELEPHANTNUMBERS:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "ElephantNumber5") as! Elephant5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .BEARNUMBERS:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "BearNumber5") as! Bear5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
  case .DEERNUMBERS:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "DeerNumber5") as! Deer5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
            
  case .TORTOISENUMBERS:
             let storyboard = UIStoryboard(name: "Main", bundle: nil)
      print("Button Tapped")

             let vc = storyboard.instantiateViewController(withIdentifier: "TortoiseNumber3") as! Tortoise3NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
                      navigationController?.pushViewController(vc, animated: true)
  case  .MONKEYNUMBERS:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "MonkeyNumber4") as! Monkey4NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .BULLNUMBERS:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "BullNumber5") as! Bull5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
  case .HORSENUMBERS:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "HorseNumber5") as! Horse5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
            
            
  case .CARNUMBERS:
             let storyboard = UIStoryboard(name: "Main", bundle: nil)
      print("Button Tapped")

             let vc = storyboard.instantiateViewController(withIdentifier: "CarNumber5") as! Car5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
                      navigationController?.pushViewController(vc, animated: true)
  case  .TRAINNUMBERS:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "TrainNumber5") as! Train5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .LORRYNUMBERS:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "LorryNumber5") as! Lorry5NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
      
  case .HELICOPTERNUMBERS:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "HelicopterNumber4") as! Helicopter4NumberViewController
      vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
      self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
  case .VANNUMBERS:
       let storyboard = UIStoryboard(name: "Main", bundle: nil)
  print("Button Tapped")

       let vc = storyboard.instantiateViewController(withIdentifier: "VanNumber5") as! Van5NumberViewController
  vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
  self.present(vc, animated: true, completion: nil)
                navigationController?.pushViewController(vc, animated: true)
  case  .AUTONUMBERS:

  let storyboard = UIStoryboard(name: "Main", bundle: nil)
  let vc = storyboard.instantiateViewController(withIdentifier: "AutoNumber5") as! Auto5NumberViewController
  vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
  self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)


  case .BUSNUMBERS:
  let storyboard = UIStoryboard(name: "Main", bundle: nil)

  let vc = storyboard.instantiateViewController(withIdentifier: "BusNumber6") as! Bus6NumberViewController
  vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
  self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)

  case .BIKENUMBERS:

  let storyboard = UIStoryboard(name: "Main", bundle: nil)

  let vc = storyboard.instantiateViewController(withIdentifier: "BikeNumber4") as! Bike4NumberViewController
  vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
  self.present(vc, animated: true, completion: nil)
      
  case .JCBNUMBERS:
       let storyboard = UIStoryboard(name: "Main", bundle: nil)
  print("Button Tapped")

       let vc = storyboard.instantiateViewController(withIdentifier: "JcbNumber5") as! Jcb5NumberViewController
  vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
  self.present(vc, animated: true, completion: nil)
                navigationController?.pushViewController(vc, animated: true)
  case  .BOATNUMBERS:

  let storyboard = UIStoryboard(name: "Main", bundle: nil)
  let vc = storyboard.instantiateViewController(withIdentifier: "BoatNumber6") as! Boat6NumberViewController
  vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
  self.present(vc, animated: true, completion: nil)
  //                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.finishColor {
              case .LEMONCOLORS:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
            print("Button Tapped")

                   let vc = storyboard.instantiateViewController(withIdentifier: "LemonColor") as! LemonColorViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .ONIONCOLORS:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "OnionColor") as! OnionColorViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .HORSECOLORS:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "HorseColor") as! HorseColorViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .BOATCOLORS:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BoatColor") as! BoatColorViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
            
    }
    @IBAction func okButton(_ sender: Any) {
        
        switch self.finishColor {
              case .LEMONCOLORS:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
            print("Button Tapped")

                   let vc = storyboard.instantiateViewController(withIdentifier: "Fruits") as! FruitsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .ONIONCOLORS:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "Vegetables") as! VegetablesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .HORSECOLORS:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Animals") as! AnimalsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .BOATCOLORS:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vehicles") as! VehiclesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
            
        }
    }
    


