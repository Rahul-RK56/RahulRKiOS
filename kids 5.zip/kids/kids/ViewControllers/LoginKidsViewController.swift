//
//  LoginKidsViewController.swift
//  kids
//
//  Created by CIPL0957 on 17/05/22.
//

import UIKit

class LoginKidsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func loginButton(_ sender: Any) {
        
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//                    let popviewController = storyboard.instantiateViewController(withIdentifier: "Welcome")
//
//                    if let presentationController = popviewController.presentationController as? UISheetPresentationController {
//                        presentationController.detents = [.large()] /// change to [.medium(), .large()] for a half and full screen sheet
//                    }
//
////                self.present(popviewController, animated: true)
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//        let vc = storyboard.instantiateViewController(withIdentifier: "Pop") as! PopViewController
//        self.present(vc, animated: true, completion: nil)
      
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let popviewController = storyboard.instantiateViewController(withIdentifier: "Pop") as! PopViewController
                        
//         
            self.present(popviewController, animated: true)
//       navigationController?.pushViewController(vc, animated: true)
    
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
