//
//  ElephantColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 24/05/22.
//

import UIKit

class ElephantColorViewController: UIViewController {
    
    @IBOutlet weak var optionBrown11: UIImageView!
    
    @IBOutlet weak var optionBlack11: UIImageView!
    
    @IBOutlet weak var optionYellow11: UIImageView!
    
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA24 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBrown11))
        optionBrown11.addGestureRecognizer(optionA24)
        optionBrown11.isUserInteractionEnabled = true
        
        let optionB24 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlack11))
        optionBlack11.addGestureRecognizer(optionB24)
        optionBlack11.isUserInteractionEnabled = true
        
        let optionC24 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionYellow11))
        optionYellow11.addGestureRecognizer(optionC24)
        optionYellow11.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionBrown11(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.ELEPHANTCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionBlack11(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.ELEPHANTCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionYellow11(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.ELEPHANTCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    
    @IBAction func backButton(_ sender: Any) {
        
//        self.navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.ELEPHANT
        self.present(vc, animated: true, completion: nil)
    }
    
    
    @IBAction func menuButton(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
