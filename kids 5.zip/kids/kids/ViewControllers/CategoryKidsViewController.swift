//
//  CategoryKidsViewController.swift
//  kids
//
//  Created by CIPL0957 on 17/05/22.
//

import UIKit

class CategoryKidsViewController: UIViewController  {

    @IBOutlet weak var FruitsImage: UIImageView!
    
    @IBOutlet weak var vegetablesImage: UIImageView!
    
    @IBOutlet weak var animalsImage: UIImageView!
    
    @IBOutlet weak var vehiclesImage: UIImageView!
    
    @IBOutlet weak var nameLbl: UILabel!
    
    @IBOutlet weak var nameView: UIView!
    
    @IBOutlet weak var welcome2: UILabel!
    
    @IBOutlet weak var nameLabel2: UILabel!
    
    @IBOutlet weak var welcome: UILabel!
    
    @IBOutlet weak var categoryView: UIScrollView!
    @IBOutlet weak var nameStackView: UIStackView!
    //    @IBOutlet weak var nameLabel: UILabel!
    var text: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
       let name1 =  UserDefaults.standard.value(forKey: "name") as? String ?? ""
//        nameLbl.text = name1
        
        if name1.count > 5 {
            welcome.isHidden = true
            nameLbl.isHidden = true
            nameView.isHidden = false
            welcome2.isHidden = false
            nameLabel2.isHidden = false
            
            nameLabel2.text = name1
        }else {
            welcome2.isHidden = true
            nameLabel2.isHidden = true
            nameView.isHidden = true
            nameLbl.text = name1
           
        }
//
//        if text != nil {
//            nameLbl.text = text
//        }

        // Do any additional setup after loading the view.
        let tapGR = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped))
        FruitsImage.addGestureRecognizer(tapGR)
        FruitsImage.isUserInteractionEnabled = true
        
        
        let tapGR1 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped1))
        vegetablesImage.addGestureRecognizer(tapGR1)
        vegetablesImage.isUserInteractionEnabled = true
        
        
        
        let tapGR2 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped2))
        animalsImage.addGestureRecognizer(tapGR2)
        animalsImage.isUserInteractionEnabled = true
        
        
        
        let tapGR3 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped3))
        vehiclesImage.addGestureRecognizer(tapGR3)
        vehiclesImage.isUserInteractionEnabled = true
    }
@objc func imageTapped(sender: UITapGestureRecognizer) {
//        if sender.state == .ended {
//                print("UIImageView tapped")
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Fruits")
            vc.modalPresentationStyle = .fullScreen
    vc.modalTransitionStyle = .crossDissolve
//            navigationController?.pushViewController(vc, animated: true)
            self.present(vc, animated: true, completion: nil)
    
    
       }
 //   }
@objc func imageTapped1(sender: UITapGestureRecognizer) {
       //     if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Vegetables")
                vc.modalPresentationStyle = .fullScreen
    vc.modalTransitionStyle = .crossDissolve
                self.present(vc, animated: true, completion: nil)
//                self.navigationController?.pushViewController(vc, animated: true)
            }
  //      }
    
    @objc func imageTapped2(sender: UITapGestureRecognizer) {
   //             if sender.state == .ended {
                        print("UIImageView tapped")
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "Animals")
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                }
   //        }
    
    
    @objc func imageTapped3(sender: UITapGestureRecognizer) {
       //         if sender.state == .ended {
                        print("UIImageView tapped")
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "Vehicles")
                    vc.modalPresentationStyle = .fullScreen
        vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      //          }
           }
    
    
    
    @IBAction func menuButton(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        
        self.present(vc, animated: true, completion: nil)
    }
    
}
