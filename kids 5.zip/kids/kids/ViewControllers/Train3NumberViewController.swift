//
//  Train3NumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 24/06/22.
//

import UIKit

class Train3NumberViewController: UIViewController {
    
    @IBOutlet weak var trainOtion3: UIImageView!
    
    @IBOutlet weak var trainOtion4: UIImageView!
    
    @IBOutlet weak var trainOtion5: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let optionA25 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption310))
        trainOtion3.addGestureRecognizer(optionA25)
        trainOtion3.isUserInteractionEnabled = true
        
        let optionB25 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption410))
        trainOtion4.addGestureRecognizer(optionB25)
        trainOtion4.isUserInteractionEnabled = true
        
        let optionC25 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption510))
        trainOtion5.addGestureRecognizer(optionC25)
        trainOtion5.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption310(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.trainType = .TRAIN2
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption410(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.trainType = .TRAIN2

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption510(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.trainType = .TRAIN2

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)

    }
    @IBAction func backButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vehicleType =  VehiclesType.TRAIN
        self.present(vc, animated: true, completion: nil)
    }
    
}
