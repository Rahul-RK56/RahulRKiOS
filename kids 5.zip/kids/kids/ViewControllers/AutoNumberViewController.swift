//
//  AutoNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class AutoNumberViewController: UIViewController {
    @IBOutlet weak var autoOption2: UIImageView!
    @IBOutlet weak var autoOption4: UIImageView!
    @IBOutlet weak var autoOption5: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
//        
        let optionA33 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption215))
        autoOption2.addGestureRecognizer(optionA33)
        autoOption2.isUserInteractionEnabled = true
        
        let optionB33 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption415))
        autoOption4.addGestureRecognizer(optionB33)
        autoOption4.isUserInteractionEnabled = true
        
        let optionC33 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption515))
        autoOption5.addGestureRecognizer(optionC33)
        autoOption5.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption215(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.autoType = .AUTO1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption415(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.autoType = .AUTO1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption515(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.autoType = .AUTO1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vehicleType =  VehiclesType.AUTO
        self.present(vc, animated: true, completion: nil)
    }
    
}
