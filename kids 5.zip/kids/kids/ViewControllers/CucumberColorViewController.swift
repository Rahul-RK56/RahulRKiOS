//
//  CucumberColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 10/06/22.
//

import UIKit

class CucumberColorViewController: UIViewController {
    @IBOutlet weak var cucumberOptionOrange: UIImageView!
    @IBOutlet weak var cucumberOptionRed: UIImageView!
    @IBOutlet weak var cucumberOptionGreen: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA21 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionOrange12))
        cucumberOptionOrange.addGestureRecognizer(optionA21)
        cucumberOptionOrange.isUserInteractionEnabled = true
        
        let optionB21 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionRed12))
        cucumberOptionRed.addGestureRecognizer(optionB21)
        cucumberOptionRed.isUserInteractionEnabled = true
        
        let optionC21 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionGreen12))
        cucumberOptionGreen.addGestureRecognizer(optionC21)
        cucumberOptionGreen.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionOrange12(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.CUCUMBERCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionRed12(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.CUCUMBERCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionGreen12(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.CUCUMBERCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vegetableType =  VegetablesType.CUCUMBER
        self.present(vc, animated: true, completion: nil)
    }
    
}
