//
//  BoatColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class BoatColorViewController: UIViewController {
    
    @IBOutlet weak var boatOptionBrown: UIImageView!
    
    @IBOutlet weak var boatOptionBlack: UIImageView!
    
    @IBOutlet weak var boatOptionBlue: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        let optionA38 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBrown21))
        boatOptionBrown.addGestureRecognizer(optionA38)
        boatOptionBrown.isUserInteractionEnabled = true
        
        let optionB38 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlack21))
        boatOptionBlack.addGestureRecognizer(optionB38)
        boatOptionBlack.isUserInteractionEnabled = true
        
        let optionC38 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlue21))
        boatOptionBlue.addGestureRecognizer(optionC38)
        boatOptionBlue.isUserInteractionEnabled = true
    }
    @objc func imageTappedOptionBrown21(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.BOATCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionBlack21(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.BOATCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionBlue21(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.BOATCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vehicleType =  VehiclesType.BOAT
        self.present(vc, animated: true, completion: nil)
    }
    
}
