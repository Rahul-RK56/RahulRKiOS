//
//  Pumpkin3NumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 22/06/22.
//

import UIKit

class Pumpkin3NumberViewController: UIViewController {
    
    @IBOutlet weak var pumpkinOption3: UIImageView!
    
    @IBOutlet weak var pumpkinOption4: UIImageView!
    
    @IBOutlet weak var pumpkinOption5: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let optionA13 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption34))
        pumpkinOption4.addGestureRecognizer(optionA13)
        pumpkinOption4.isUserInteractionEnabled = true
        
        let optionB13 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption44))
        pumpkinOption5.addGestureRecognizer(optionB13)
        pumpkinOption5.isUserInteractionEnabled = true
        
        let optionC13 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption54))
        pumpkinOption3.addGestureRecognizer(optionC13)
        pumpkinOption3.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption34(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.pumpkinType = .PUMPKIN3

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption44(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.pumpkinType = .PUMPKIN3

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption54(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.pumpkinType = .PUMPKIN3
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vegetableType =  VegetablesType.PUMPKIN
        self.present(vc, animated: true, completion: nil)
    }
    
}
