//
//  AlertPopupViewController.swift
//  kids
//
//  Created by CIPL0957 on 30/06/22.
//

import UIKit

class AlertPopupViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        view.backgroundColor = .lightText
    }
    
//    override func viewDidLayoutSubviews() {
//        super.viewDidLayoutSubviews()
//
//        let blur:UIBlurEffect = UIBlurEffect(style: UIBlurEffect.Style.light)
//
//        let effectView:UIVisualEffectView = UIVisualEffectView (effect: blur)
////        effectView.frame = frame
//        view.addSubview(effectView)
//    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func okButton(_ sender: Any) {
        dismiss(animated: true)
    }
    
}
