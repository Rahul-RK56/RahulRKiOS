//
//  ANViewController.swift
//  kids
//
//  Created by CIPL0957 on 19/05/22.
//

import UIKit



class AppleNumberViewController: UIViewController {

    @IBOutlet weak var option3: UIImageView!
    
    @IBOutlet weak var option4: UIImageView!
    
    @IBOutlet weak var option5: UIImageView!
    
   // @IBOutlet weak var cView: UICollectionView!
    
//    @IBOutlet weak var AppleStackView: UIStackView!
//    var myImageView:UIImageView = UIImageView()
//
//    var numberOfApple = ["1", "2" ,"3"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
       
//
//        let AppleImage = UIImage(named: "app")
//        let myImageView:UIImageView = UIImageView()
//        myImageView.contentMode = UIView.ContentMode.scaleAspectFit
//        myImageView.frame.size.width = 60
//        myImageView.frame.size.height = 60
//        myImageView.center = self.view.center
//        myImageView.image = AppleImage
//        AppleStackView.addSubview(myImageView)

        let optionA1 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption3))
        option3.addGestureRecognizer(optionA1)
        option3.isUserInteractionEnabled = true
        
        let optionB1 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption4))
        option4.addGestureRecognizer(optionB1)
        option4.isUserInteractionEnabled = true
        
        let optionC1 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption5))
        option5.addGestureRecognizer(optionC1)
        option5.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption3(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.appleType =  ApplesType.APPLE1
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                self.present(vc, animated: true, completion: nil)
                
        
           }
        
        }
    
    @objc func imageTappedOption4(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
//
                vc.appleType =  ApplesType.APPLE1
                self.present(vc, animated: true, completion: nil)
        
        
           }
        }
    
    @objc func imageTappedOption5(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.appleType =  ApplesType.APPLE1
//                vc.vehicleType = VehiclesType.CAR
                
                self.present(vc, animated: true, completion: nil)
        
        
           }
        }
   

    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .fullScreen
        vc.fruitType =  FruitsType.APPLE
        self.present(vc, animated: true, completion: nil)
        
    }
   
}

