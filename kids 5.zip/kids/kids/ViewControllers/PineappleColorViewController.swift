//
//  PineappleColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 10/06/22.
//

import UIKit

class PineappleColorViewController: UIViewController {

    @IBOutlet weak var pineappleOptionOrange: UIImageView!
    
    @IBOutlet weak var pineappleOptionRed: UIImageView!
    
    @IBOutlet weak var pineappleOptionYellow: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA14 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionOrange9))
        pineappleOptionOrange.addGestureRecognizer(optionA14)
        pineappleOptionOrange.isUserInteractionEnabled = true
        
        let optionB14 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionRed9))
        pineappleOptionRed.addGestureRecognizer(optionB14)
        pineappleOptionRed.isUserInteractionEnabled = true
        
        let optionC14 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionYellow9))
        pineappleOptionYellow.addGestureRecognizer(optionC14)
        pineappleOptionYellow.isUserInteractionEnabled = true
    }
    @objc func imageTappedOptionOrange9(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.PINEAPPLECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionRed9(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                 vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.PINEAPPLECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionYellow9(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.PINEAPPLECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.fruitType =  FruitsType.PINEAPPLE
        self.present(vc, animated: true, completion: nil)
    }
}
