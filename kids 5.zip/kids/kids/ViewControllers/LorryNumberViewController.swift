//
//  LooryNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 25/05/22.
//

import UIKit

class LorryNumberViewController: UIViewController {
    
    @IBOutlet weak var option212: UIImageView!
    
    @IBOutlet weak var option412: UIImageView!
    
    @IBOutlet weak var option512: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA29 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption212))
        option212.addGestureRecognizer(optionA29)
        option212.isUserInteractionEnabled = true
        
        let optionB29 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption412))
        option412.addGestureRecognizer(optionB29)
        option412.isUserInteractionEnabled = true
        
        let optionC29 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption512))
        option512.addGestureRecognizer(optionC29)
        option512.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption212(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.lorryType = .LORRY1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption412(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.lorryType = .LORRY1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption512(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.lorryType = .LORRY1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vehicleType =  VehiclesType.LORRY
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func menuButton(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
}
