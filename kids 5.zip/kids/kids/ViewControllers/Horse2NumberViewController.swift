//
//  Horse2NumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 23/06/22.
//

import UIKit

class Horse2NumberViewController: UIViewController {
    
    @IBOutlet weak var horseNumber2: UIImageView!
    
    @IBOutlet weak var horseNumber4: UIImageView!
    
    @IBOutlet weak var horseNumber5: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let optionA17 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption36))
        horseNumber4.addGestureRecognizer(optionA17)
        horseNumber4.isUserInteractionEnabled = true
        
        let optionB17 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption46))
        horseNumber2.addGestureRecognizer(optionB17)
        horseNumber2.isUserInteractionEnabled = true
        
        let optionC17 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption56))
        horseNumber5.addGestureRecognizer(optionC17)
        horseNumber5.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption36(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.horseType = .HORSE2

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption46(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.horseType = .HORSE2
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption56(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.horseType = .HORSE2

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.HORSE
        self.present(vc, animated: true, completion: nil)
    }
    
}
