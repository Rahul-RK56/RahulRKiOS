//
//  MonkeyNUmberViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class MonkeyNumberViewController: UIViewController {

    @IBOutlet weak var monkeyOption2: UIImageView!
    @IBOutlet weak var monkeyOption4: UIImageView!
    @IBOutlet weak var monkeyOption5: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA27 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption33))
        monkeyOption2.addGestureRecognizer(optionA27)
        monkeyOption2.isUserInteractionEnabled = true
        
        let optionB27 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption43))
        monkeyOption4.addGestureRecognizer(optionB27)
        monkeyOption4.isUserInteractionEnabled = true
        
        let optionC27 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption53))
        monkeyOption5.addGestureRecognizer(optionC27)
        monkeyOption5.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption33(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.monkeyType = .MONKEY1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption43(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.monkeyType = .MONKEY1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption53(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.monkeyType = .MONKEY1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.MONKEY
        self.present(vc, animated: true, completion: nil)
    }
}
