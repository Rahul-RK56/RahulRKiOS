//
//  LogoutAlertViewController.swift
//  kids
//
//  Created by CIPL0957 on 30/06/22.
//

import UIKit

class LogoutAlertViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
//     view.backgroundColor = .lightText
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func yesButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "Login") as! LoginKidsViewController
        vc.modalTransitionStyle = .crossDissolve
          vc.modalPresentationStyle = .fullScreen
//            navigationController?.pushViewController(vc, animated: true)
    self.present(vc, animated: true, completion: nil)
        
    }
    @IBAction func noButton(_ sender: Any) {
        dismiss(animated: true)
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        let vc = storyboard.instantiateViewController(withIdentifier: "CategoryKids") as! CategoryKidsViewController
//        vc.modalPresentationStyle = .fullScreen
//            vc.modalTransitionStyle = .crossDissolve
//        self.present(vc, animated: true)
    }
    
}
