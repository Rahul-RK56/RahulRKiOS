//
//  DogColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 24/05/22.
//

import UIKit

class DogColorViewController: UIViewController {
    
    @IBOutlet weak var optionBrown10: UIImageView!
    
    @IBOutlet weak var optionBlack10: UIImageView!
    
    @IBOutlet weak var optionBlue10: UIImageView!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let option22 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBrown10))
        optionBrown10.addGestureRecognizer(option22)
        optionBrown10.isUserInteractionEnabled = true
        
        let optionB22 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlack10))
        optionBlack10.addGestureRecognizer(optionB22)
        optionBlack10.isUserInteractionEnabled = true
        
        let optionC22 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlue10))
        optionBlue10.addGestureRecognizer(optionC22)
        optionBlue10.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionBrown10(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.DOGCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionBlack10(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.DOGCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionBlue10(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.DOGCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.DOG
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func menuButton(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
}
