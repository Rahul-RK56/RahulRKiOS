//
//  TortoiseNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class TortoiseNumberViewController: UIViewController {
    @IBOutlet weak var tortioseOption2: UIImageView!
    
    @IBOutlet weak var tortioseOption4: UIImageView!
    
    @IBOutlet weak var tortioseOption5: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA26 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption32))
        tortioseOption2.addGestureRecognizer(optionA26)
        tortioseOption2.isUserInteractionEnabled = true
        
        let optionB26 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption42))
        tortioseOption4.addGestureRecognizer(optionB26)
        tortioseOption4.isUserInteractionEnabled = true
        
        let optionC26 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption52))
        tortioseOption5.addGestureRecognizer(optionC26)
        tortioseOption5.isUserInteractionEnabled = true
    }
    @objc func imageTappedOption32(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.tortoiseType = .TORTOISE1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption42(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.tortoiseType = .TORTOISE1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption52(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.tortoiseType = .TORTOISE1

                self.present(vc, animated: true, completion: nil)
        
           }
        }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func menuButton(_ sender: Any) {
    
    let storyboard = UIStoryboard(name: "Main", bundle: nil)
    
    let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
    self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.TORTOISE
        self.present(vc, animated: true, completion: nil)
    }
}
