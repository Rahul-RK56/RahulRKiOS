//
//  PotatoNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 23/05/22.
//

import UIKit

class PotatoNumberViewController: UIViewController {
    
    @IBOutlet weak var option25: UIImageView!
    
    @IBOutlet weak var option45: UIImageView!
    
    @IBOutlet weak var option55: UIImageView!
    
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA15 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption25))
        option25.addGestureRecognizer(optionA15)
        option25.isUserInteractionEnabled = true
        
        let optionB15 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption45))
        option45.addGestureRecognizer(optionB15)
        option45.isUserInteractionEnabled = true
        
        let optionC15 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption55))
        option55.addGestureRecognizer(optionC15)
        option55.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption25(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.potatoType = .POTATO1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption45(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.potatoType = .POTATO1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption55(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.potatoType = .POTATO1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vegetableType =  VegetablesType.POTATO
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
}
