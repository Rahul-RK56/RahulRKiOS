//
//  PotatoColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 23/05/22.
//

import UIKit

class PotatoColorViewController: UIViewController {
    
    @IBOutlet weak var optionGreen7: UIImageView!
    
    @IBOutlet weak var optionBrown7: UIImageView!
    
    @IBOutlet weak var optionBlack7: UIImageView!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA16 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionGreen7))
        optionGreen7.addGestureRecognizer(optionA16)
        optionGreen7.isUserInteractionEnabled = true
        
        let optionB16 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBrown7))
        optionBrown7.addGestureRecognizer(optionB16)
        optionBrown7.isUserInteractionEnabled = true
        
        let optionC16 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlack7))
        optionBlack7.addGestureRecognizer(optionC16)
        optionBlack7.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionGreen7(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.POTATOCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionBrown7(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.POTATOCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionBlack7(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.POTATOCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func backButton(_ sender: Any) {
        
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vegetableType =  VegetablesType.POTATO
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
}
