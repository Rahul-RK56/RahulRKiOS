//
//  MonkeyColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class MonkeyColorViewController: UIViewController {
    @IBOutlet weak var monkeyOptionBrown: UIImageView!
    
    @IBOutlet weak var monkeyOptionBlack: UIImageView!
    
    @IBOutlet weak var monkeyOptionYeelow: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA28 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBrown15))
        monkeyOptionBlack.addGestureRecognizer(optionA28)
        monkeyOptionBlack.isUserInteractionEnabled = true
        
        let optionB28 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlack15))
        monkeyOptionBrown.addGestureRecognizer(optionB28)
        monkeyOptionBrown.isUserInteractionEnabled = true
        
        let optionC28 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionYellow15))
        monkeyOptionYeelow.addGestureRecognizer(optionC28)
        monkeyOptionYeelow.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionBrown15(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.MONKEYCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionBlack15(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.MONKEYCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionYellow15(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                

                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.colorType = ColorsType.MONKEYCOLOR
                vc.modalPresentationStyle = .custom
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backButon(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.MONKEY
        self.present(vc, animated: true, completion: nil)
    }
}
