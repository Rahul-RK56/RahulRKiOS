//
//  OrangeNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 20/05/22.
//

import UIKit

class OrangeNumberViewController: UIViewController {
    
    
    @IBOutlet weak var option31: UIImageView!
    
    @IBOutlet weak var option41: UIImageView!
    
    @IBOutlet weak var option51: UIImageView!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA7 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption31))
        option31.addGestureRecognizer(optionA7)
        option31.isUserInteractionEnabled = true
        
        let optionB7 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption41))
        option41.addGestureRecognizer(optionB7)
        option41.isUserInteractionEnabled = true
        
        let optionC7 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption51))
        option51.addGestureRecognizer(optionC7)
        option51.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption31(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.orangeType = .ORANGE1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption41(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.orangeType = .ORANGE1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption51(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.orangeType = .ORANGE1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//    dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.fruitType =  FruitsType.ORANGE
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
}
