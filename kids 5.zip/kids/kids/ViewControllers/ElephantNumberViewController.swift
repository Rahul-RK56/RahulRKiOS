//
//  ElephantNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 24/05/22.
//

import UIKit

class ElephantNumberViewController: UIViewController {
    
    @IBOutlet weak var option29: UIImageView!
    
    @IBOutlet weak var option49: UIImageView!
    
    @IBOutlet weak var option59: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA23 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption29))
        option29.addGestureRecognizer(optionA23)
        option29.isUserInteractionEnabled = true
        
        let optionB23 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption49))
        option49.addGestureRecognizer(optionB23)
        option49.isUserInteractionEnabled = true
        
        let optionC23 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption59))
        option59.addGestureRecognizer(optionC23)
        option59.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption29(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.elephantType = .ELEPHANT1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption49(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.elephantType = .ELEPHANT1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption59(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.elephantType = .ELEPHANT1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.ELEPHANT
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func menuButton(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
}
