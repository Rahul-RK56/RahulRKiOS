//
//  TrainNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 25/05/22.
//

import UIKit

class TrainNumberViewController: UIViewController {
    
    @IBOutlet weak var option211: UIImageView!
    
    @IBOutlet weak var option411: UIImageView!
    
    @IBOutlet weak var option511: UIImageView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA27 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption211))
        option211.addGestureRecognizer(optionA27)
        option211.isUserInteractionEnabled = true
        
        let optionB27 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption411))
        option411.addGestureRecognizer(optionB27)
        option411.isUserInteractionEnabled = true
        
        let optionC27 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption511))
        option511.addGestureRecognizer(optionC27)
        option511.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption211(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.trainType = .TRAIN1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption411(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.trainType = .TRAIN1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption511(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.trainType = .TRAIN1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vehicleType =  VehiclesType.TRAIN
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func menuButton(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
}
