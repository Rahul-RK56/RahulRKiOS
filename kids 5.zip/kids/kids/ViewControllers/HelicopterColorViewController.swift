//
//  HelicopterColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 25/05/22.
//

import UIKit

class HelicopterColorViewController: UIViewController {
    
    @IBOutlet weak var optionBrown15: UIImageView!
    
    @IBOutlet weak var optionBlack15: UIImageView!
    
    @IBOutlet weak var optionBlue15: UIImageView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA32 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBrown15))
        optionBrown15.addGestureRecognizer(optionA32)
        optionBrown15.isUserInteractionEnabled = true
        
        let optionB32 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlack15))
        optionBlack15.addGestureRecognizer(optionB32)
        optionBlack15.isUserInteractionEnabled = true
        
        let optionC32 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlue15))
        optionBlue15.addGestureRecognizer(optionC32)
        optionBlue15.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionBrown15(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.HELICOPTERCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionBlack15(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.HELICOPTERCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionBlue15(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.HELICOPTERCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vehicleType =  VehiclesType.HELICOPTER
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func menuButton(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
}
