//
//  BearColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class BearColorViewController: UIViewController {
    @IBOutlet weak var bearOptionBrown: UIImageView!
    @IBOutlet weak var bearOptionBlack: UIImageView!
    
    @IBOutlet weak var bearOptionRed: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA25 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBrown12))
        bearOptionBrown.addGestureRecognizer(optionA25)
        bearOptionBrown.isUserInteractionEnabled = true
        
        let optionB25 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlack12))
        bearOptionBlack.addGestureRecognizer(optionB25)
        bearOptionBlack.isUserInteractionEnabled = true
        
        let optionC25 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionRed12))
        bearOptionRed.addGestureRecognizer(optionC25)
        bearOptionRed.isUserInteractionEnabled = true
    }
    @objc func imageTappedOptionBrown12(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.BEARCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionBlack12(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.BEARCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionRed12(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.BEARCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.BEAR
        self.present(vc, animated: true, completion: nil)
    }
}
