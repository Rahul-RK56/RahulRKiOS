//
//  ACViewController.swift
//  kids
//
//  Created by CIPL0957 on 19/05/22.
//

import UIKit

class AppleColorViewController: UIViewController {
    
    @IBOutlet weak var optionBlue: UIImageView!
    
    @IBOutlet weak var optionRed: UIImageView!
    
    @IBOutlet weak var optionGreen: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view
        
        let optionA2 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlue))
        optionBlue.addGestureRecognizer(optionA2)
        optionBlue.isUserInteractionEnabled = true
        
        let optionB2 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionRed))
        optionRed.addGestureRecognizer(optionB2)
        optionRed.isUserInteractionEnabled = true
        
        let optionC2 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionGreen))
        optionGreen.addGestureRecognizer(optionC2)
        optionGreen.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionBlue(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.APPLECOLOR
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionRed(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.APPLECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionGreen(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.APPLECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }

    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.fruitType =  FruitsType.APPLE
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
}
