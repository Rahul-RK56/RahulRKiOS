//
//  JcbNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class JcbNumberViewController: UIViewController {
    @IBOutlet weak var jcbOption2: UIImageView!
    @IBOutlet weak var jcbOption4: UIImageView!
    @IBOutlet weak var jcbOption5: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA36 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption218))
        jcbOption2.addGestureRecognizer(optionA36)
        jcbOption2.isUserInteractionEnabled = true
        
        let optionB36 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption418))
        jcbOption4.addGestureRecognizer(optionB36)
        jcbOption4.isUserInteractionEnabled = true
        
        let optionC36 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption518))
        jcbOption5.addGestureRecognizer(optionC36)
        jcbOption5.isUserInteractionEnabled = true
    }
    @objc func imageTappedOption218(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.jcbType = .JCB1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption418(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.jcbType = .JCB1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption518(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.jcbType = .JCB1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vehicleType =  VehiclesType.JCB
        self.present(vc, animated: true, completion: nil)
    }
    
}
