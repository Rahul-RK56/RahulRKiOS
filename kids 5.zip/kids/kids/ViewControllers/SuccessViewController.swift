//
//  SuccessViewController.swift
//  kids
//
//  Created by CIPL0957 on 26/05/22.
//

    
import UIKit
import AVFoundation

enum ApplesType {
  case APPLE1
  case APPLE2
  case APPLE3
  case APPLE4
  
}

enum BananasType {
  case BANANA1
  case BANANA2
  case BANANA3
  case BANANA4
  
}
enum MangoesType {
  case MANGO1
  case MANGO2
  case MANGO3
  case MANGO4
  
}

enum OrangesType {
  case ORANGE1
  case ORANGE2
  case ORANGE3
  case ORANGE4
  
}

enum StrawberriesType {
  case STRAWBERRY1
  case STRAWBERRY2
  case STRAWBERRY3
  case STRAWBERRY4
  
}

enum GuavasType {
  case GUAVA1
  case GUAVA2
  case GUAVA3
  case GUAVA4
  
}

enum WatermelonsType {
  case WATERMELON1
  case WATERMELON2
  case WATERMELON3
  case WATERMELON4
  
}

enum GrapesType {
  case GRAPE1
  case GRAPE2
  case GRAPE3
  case GRAPE4
  
}

enum PineapplesType {
  case PINEAPPLE1
  case PINEAPPLE2
  case PINEAPPLE3
  case PINEAPPLE4
  
}

enum LemonsType {
  case LEMON1
  case LEMON2
  case LEMON3
  case LEMON4
  
}

enum TomatoesType {
  case TOMATO1
  case TOMATO2
  case TOMATO3
  case TOMATO4
  
}
enum CarrotsType {
  case CARROT1
  case CARROT2
  case CARROT3
  case CARROT4
  
}
enum BrinjalsType {
  case BRINJAL1
  case BRINJAL2
  case BRINJAL3
  case BRINJAL4
  
}
enum PotatoesType {
  case POTATO1
  case POTATO2
  case POTATO3
  case POTATO4
  
}

enum ChilliesType {
  case CHILLI1
  case CHILLI2
  case CHILLI3
  case CHILLI4
  
}

enum PumpkinsType {
  case PUMPKIN1
  case PUMPKIN2
  case PUMPKIN3
  case PUMPKIN4
  
}
enum CauliflowersType {
  case CAULIFLOWER1
  case CAULIFLOWER2
  case CAULIFLOWER3
  case CAULIFLOWER4
  
}
enum CabbagesType {
  case CABBAGE1
  case CABBAGE2
  case CABBAGE3
  case CABBAGE4
  
}
enum CucumbersType {
  case CUCUMBER1
  case CUCUMBER2
  case CUCUMBER3
  case CUCUMBER4
  
}

enum OnionsType {
  case ONION1
  case ONION2
  case ONION3
  case ONION4
  
}

enum CowsTypes {
  case COW1
  case COW2
  case COW3
  case COW4
  
}
enum LionsTypes {
  case LION1
  case LION2
  case LION3
  case LION4
  
}
enum DogsTypes {
  case DOG1
  case DOG2
  case DOG3
  case DOG4
  
}
enum ElephantsTypes {
  case ELEPHANT1
  case ELEPHANT2
  case ELEPHANT3
  case ELEPHANT4
  
}
enum BearsTypes {
  case BEAR1
  case BEAR2
  case BEAR3
  case BEAR4
  
}
enum DeersTypes {
  case DEER1
  case DEER2
  case DEER3
  case DEER4
  
}
enum TortoisesTypes {
  case TORTOISE1
  case TORTOISE2
  case TORTOISE3
  case TORTOISE4
  
}
enum MonkiesTypes {
  case MONKEY1
  case MONKEY2
  case MONKEY3
  case MONKEY4
  
}

enum BullsTypes {
  case BULL1
  case BULL2
  case BULL3
  case BULL4
  
}

enum HorsesTypes {
  case HORSE1
  case HORSE2
  case HORSE3
  case HORSE4
  
}
enum CarsTypes {
  case CAR1
  case CAR2
  case CAR3
  case CAR4
  
}

enum TrainsTypes {
  case TRAIN1
  case TRAIN2
  case TRAIN3
  case TRAIN4
  
}

enum LorriesTypes {
  case LORRY1
  case LORRY2
  case LORRY3
  case LORRY4
  
}

enum HelicoptersTypes {
  case HELICOPTER1
  case HELICOPTER2
  case HELICOPTER3
  case HELICOPTER4
  
}
enum VansTypes {
  case VAN1
  case VAN2
  case VAN3
  case VAN4
  
}
enum AutosTypes {
  case AUTO1
  case AUTO2
  case AUTO3
  case AUTO4
  
}

enum BusesTypes {
  case BUS1
  case BUS2
  case BUS3
  case BUS4
  
}

enum BikesTypes {
  case BIKE1
  case BIKE2
  case BIKE3
  case BIKE4
  
}

enum JcbTypes {
  case JCB1
  case JCB2
  case JCB3
  case JCB4
  
}

enum BoatsTypes {
  case BOAT1
  case BOAT2
  case BOAT3
  case BOAT4
  
}


//var apple = 1
class SuccessViewController: UIViewController {
    
    var appleType: ApplesType?
    var bananaType: BananasType?
    var mangoType: MangoesType?
    var orangeType: OrangesType?
    var strawberryType: StrawberriesType?
    var guavaType: GuavasType?
    var watermelonType: WatermelonsType?
    var grapeType: GrapesType?
    var pineappleType: PineapplesType?
    var lemonType: LemonsType?
    var tomatoType: TomatoesType?
    var carrotType: CarrotsType?
    var brinjalType: BrinjalsType?
    var potatoType: PotatoesType?
    var chilliType: ChilliesType?
    var pumpkinType: PumpkinsType?
    var cauliflowerType: CauliflowersType?
    var cabbageType: CabbagesType?
    var cucumberType: CucumbersType?
    var onionType: OnionsType?
    var cowType: CowsTypes?
    var lionType: LionsTypes?
    var dogType: DogsTypes?
    var elephantType: ElephantsTypes?
    var bearType: BearsTypes?
    var deerType: DeersTypes?
    var tortoiseType: TortoisesTypes?
    var monkeyType: MonkiesTypes?
    var bullType: BullsTypes?
    var horseType: HorsesTypes?
    var carType: CarsTypes?
    var trainType: TrainsTypes?
    var lorryType: LorriesTypes?
    var helicopterType: HelicoptersTypes?
    var vanType: VansTypes?
    var autoType: AutosTypes?
    var busType: BusesTypes?
    var bikeType: BikesTypes?
    var jcbType: JcbTypes?
    var boatType: BoatsTypes?
    var colorType: ColorsType?
    

//    var player : AVAudioPlayer!
    var objPlayer: AVAudioPlayer?

    @IBOutlet weak var topImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        view.backgroundColor = .lightText
        
    

    
        
        do {
               let imageData = try Data(contentsOf: Bundle.main.url(forResource: "Win", withExtension: "gif")!)
               self.topImage.image = UIImage.gif(data: imageData)
           } catch {
               print(error)
           }
      
//        successSound()
        playAudioFile()
//        playAudioFromProject()

    }
    
    func playAudioFile() {
        guard let url = Bundle.main.url(forResource: "success", withExtension: "m4a") else { return }

        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playback)
            try AVAudioSession.sharedInstance().setActive(true)

            // For iOS versions < 11
            objPlayer = try AVAudioPlayer(contentsOf: url)// AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3)

            guard let aPlayer = objPlayer else { return }
            aPlayer.play()

        } catch let error {
            print(error.localizedDescription)
        }
    }
    
//    func successSound(){
//            if let sound = Bundle.main.url(forResource: "success", withExtension: "m4a") {
//                do {
//                    print("hi")
//                    player = try AVAudioPlayer(contentsOf:sound)
//                    player.play()
//                }catch{
//                    print("not play")
//                }
//            }else{
//                print("......")
//            }
//        }
    
    
//    private func playAudioFromProject() {
//            guard let url = Bundle.main.url(forResource: "success", withExtension: "mp3") else {
//                print("error to get the mp3 file")
//                return
//            }
//
//            do {
//                audioPlayer = try AVPlayer(url: url)
//            } catch {
////                print("audio file error")
//
//            }
//            audioPlayer?.play()
//        }




    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
       // let vc = AppleNumberViewController()
//         vc.numberOfApple = ["1", "2", "3","4", "5"]
//        vc.viewWillAppear(true)
    }
    
    @IBAction func cancel(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func retry(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func home(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "CategoryKids") as! CategoryKidsViewController
        vc.modalPresentationStyle = .fullScreen
        vc.modalTransitionStyle = .crossDissolve
       // navigationController?.pushViewController(vc, animated: true)
        self.present(vc, animated: true, completion: nil)
    }
    
    
    @IBAction func nextButton(_ sender: Any) {
//        
//       apple = Int.random(in: 1...5)
//              print("apple-----",apple)
//       self.dismiss(animated: true, completion: nil)
        switch self.appleType {
              case .APPLE1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
            print("Button Tapped")

                   let vc = storyboard.instantiateViewController(withIdentifier: "AppleNumber2") as! Apple2NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .APPLE2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "AppleNumber4") as! Apple4NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .APPLE3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "AppleNumber5") as! Apple5NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        case .APPLE4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.LEMONCOLORS
            vc.finishNumber = FinishNumbers.APPLENUMBERS
            vc.modalPresentationStyle = .fullScreen
//            vc.modalTransitionStyle = .partialCurl
            self.present(vc, animated: true, completion: nil)
            
        
        default: break
          }
        
        switch self.bananaType {
              case .BANANA1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "BananaNumber2") as! Banana2NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .BANANA2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BananaNumber3") as! Banana3NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .BANANA3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BananaNumber5") as! Banana5NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        case .BANANA4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.LEMONCOLORS
            vc.finishNumber = FinishNumbers.BANANANUMBERS
            vc.modalPresentationStyle = .fullScreen
//            vc.modalTransitionStyle = .partialCurl
            self.present(vc, animated: true, completion: nil)
            
    
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.mangoType {
              case .MANGO1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "MangoNumber4") as! Mango4NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .MANGO2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "MangoNumber5") as! Mango5NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .MANGO3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "MangoNumber3") as! Mango3NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        case .MANGO4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.LEMONCOLORS
            vc.finishNumber = FinishNumbers.MANGONUMBERS
            vc.modalPresentationStyle = .fullScreen
//            vc.modalTransitionStyle = .partialCurl
            self.present(vc, animated: true, completion: nil)
            
       
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.orangeType {
              case .ORANGE1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "OrangeNumber2") as! Orange2NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .ORANGE2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "OrangeNumber4") as! Orange4NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .ORANGE3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "OrangeNumber3") as! Orange3NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        case .ORANGE4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.LEMONCOLORS
            vc.finishNumber = FinishNumbers.ORANGENUMBERS
            vc.modalPresentationStyle = .fullScreen
//            vc.modalTransitionStyle = .partialCurl
            self.present(vc, animated: true, completion: nil)
        
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.strawberryType {
        case .STRAWBERRY1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "StrawberryNumber5") as! Strawberry5NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .STRAWBERRY2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "StrawberryNumber2") as! Strawberry2NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .STRAWBERRY3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "StrawberryNumber4") as! Strawberry4NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        case .STRAWBERRY4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.LEMONCOLORS
            vc.finishNumber = FinishNumbers.STRAWBERRYNUMBERS
            vc.modalPresentationStyle = .fullScreen
//            vc.modalTransitionStyle = .partialCurl
            self.present(vc, animated: true, completion: nil)
            
      
        default: break
          }
        
        switch self.guavaType {
              case .GUAVA1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "GuavaNumber2") as! Guava2NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .GUAVA2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "GuavaNumber3") as! Guava3NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .GUAVA3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "GuavaNumber5") as! Guava5NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        case .GUAVA4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.LEMONCOLORS
            vc.finishNumber = FinishNumbers.GUAVANUMBERS
            vc.modalPresentationStyle = .fullScreen
//            vc.modalTransitionStyle = .partialCurl
            self.present(vc, animated: true, completion: nil)
            
        
        default: break
          }
        
        switch self.watermelonType {
              case .WATERMELON1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "WatermelonNumber3") as! Watermelon3NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .WATERMELON2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "WatermelonNumber4") as! Watermelon4NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .WATERMELON3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "WatermelonNumber5") as! Watermelon5NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .partialCurl
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        case .WATERMELON4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.LEMONCOLORS
            vc.finishNumber = FinishNumbers.WATERMELONNUMBERS
            vc.modalPresentationStyle = .fullScreen
//            vc.modalTransitionStyle = .partialCurl
            self.present(vc, animated: true, completion: nil)
            
       
        default: break
          }
        switch self.grapeType {
              case .GRAPE1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "GrapeNumber2") as! Grape2NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .GRAPE2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "GrapeNumber3") as! Grape3NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .GRAPE3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "GrapeNumber4") as! Grape4NUmberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .GRAPE4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.LEMONCOLORS
            vc.finishNumber = FinishNumbers.GRAPENUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.pineappleType {
              case .PINEAPPLE1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "PineappleNumber3") as! Pineapple3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .partialCurl
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .PINEAPPLE2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "PineappleNumber4") as! Pineapple4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .partialCurl
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .PINEAPPLE3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "PineappleNumber5") as! Pineapple5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .PINEAPPLE4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.LEMONCOLORS
            vc.finishNumber = FinishNumbers.PINEAPPLENUMBERS
            vc.modalPresentationStyle = .fullScreen
//            vc.modalTransitionStyle = .partialCurl
            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.lemonType {
              case .LEMON1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "LemonNumber2") as! Lemon2NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .LEMON2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "LemonNumber3") as! Lemon3NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .LEMON3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "LemonNumber5") as! Lemon5NumberViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .LEMON4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.LEMONCOLORS
            vc.finishNumber = FinishNumbers.LEMONNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        
        
        switch self.tomatoType {
              case .TOMATO1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "TomatoNumber2") as! Tomato2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .TOMATO2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "TomatoNumber4") as! Tomato4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .TOMATO3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "TomatoNumber5") as! Tomato5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .TOMATO4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.ONIONCOLORS
            vc.finishNumber = FinishNumbers.TOMATONUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.carrotType {
              case .CARROT1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "CarrotNumber2") as! Carrot2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .CARROT2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "CarrotNumber3") as! Carrot3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .CARROT3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "CarrotNumber5") as! Carrot5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .CARROT4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.ONIONCOLORS
            vc.finishNumber = FinishNumbers.CARROTNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.brinjalType {
              case .BRINJAL1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "BrinjalNumber2") as! Brinjal2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .BRINJAL2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BrinjalNumber3") as! Brinjal3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .BRINJAL3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BrinjalNumber4") as! Brinjal4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .BRINJAL4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.ONIONCOLORS
            vc.finishNumber = FinishNumbers.BRINJALNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.potatoType {
              case .POTATO1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "PotatoNumber4") as! Potato4NumberViewController
            vc.modalTransitionStyle = .partialCurl
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .POTATO2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "PotatoNumber5") as! Potato5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .POTATO3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "PotatoNumber3") as! Potato3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .POTATO4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.ONIONCOLORS
            vc.finishNumber = FinishNumbers.POTATONUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.chilliType {
        case .CHILLI1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "ChilliNumber2") as! Chilli2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .CHILLI2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "ChilliNumber4") as! Chilli4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .CHILLI3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "ChilliNumber5") as! Chilli5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .CHILLI4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.ONIONCOLORS
            vc.finishNumber = FinishNumbers.CHILLINUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.pumpkinType {
              case .PUMPKIN1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "PumpkinNumber2") as! Pumpkin2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .PUMPKIN2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "PumpkinNumber3") as! Pumpkin3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .PUMPKIN3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "PumpkinNumber4") as! Pumpkin4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .PUMPKIN4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.ONIONCOLORS
            vc.finishNumber = FinishNumbers.PUMPKINNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.cauliflowerType {
              case .CAULIFLOWER1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "CauliflowerNumber4") as! Cauliflower4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .CAULIFLOWER2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "CauliflowerNumber5") as! Cauliflower5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .CAULIFLOWER3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "CauliflowerNumber3") as! Cauliflower3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
//
        case .CAULIFLOWER4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.ONIONCOLORS
            vc.finishNumber = FinishNumbers.CAULIFLOWERNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.cabbageType {
              case .CABBAGE1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "CabbageNumber2") as! Cabbage2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .CABBAGE2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "CabbageNumber3") as! Cabbage3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .CABBAGE3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "CabbageNumber5") as! Cabbage5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .CABBAGE4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.ONIONCOLORS
            vc.finishNumber = FinishNumbers.CABBAGENUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.cucumberType {
              case .CUCUMBER1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "CucumberNumber2") as! Cucumber2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .CUCUMBER2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "CucumberNumber4") as! Cucumber4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .CUCUMBER3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "CucumberNumber5") as! Cucumber5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .CUCUMBER4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.ONIONCOLORS
            vc.finishNumber = FinishNumbers.CUCUMBERNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.onionType {
              case .ONION1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "OnionNumber2") as! Onion2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .ONION2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "OnionNumber3") as! Onion3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .ONION3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "OnionNumber4") as! Onion4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .ONION4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.ONIONCOLORS
            vc.finishNumber = FinishNumbers.ONIONNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
      //  navigationController?.pushViewController(vc, animated: true)
        
       // self.present(vc, animated: true, completion: nil)
        
        switch self.cowType {
              case .COW1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "CowNumber2") as! Cow2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .COW2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "CowNumber3") as! Cow3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .COW3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "CowNumber5") as! Cow5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .COW4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.HORSECOLORS
            vc.finishNumber = FinishNumbers.COWNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.lionType {
              case .LION1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "LionNumber2") as! Lion2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .LION2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "LionNumber4") as! Lion4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .LION3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "LionNumber5") as! Lion5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .LION4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.HORSECOLORS
            vc.finishNumber = FinishNumbers.LIONNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.dogType {
              case .DOG1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "DogNumber2") as! Dog2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .DOG2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "DogNumber4") as! Dog4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .DOG3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "DogNumber5") as! Dog5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .DOG4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.HORSECOLORS
            vc.finishNumber = FinishNumbers.DOGNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.elephantType {
              case .ELEPHANT1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "ElephantNumber3") as! Elephant3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .ELEPHANT2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "ElephantNumber4") as! Elephant4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .ELEPHANT3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "ElephantNumber5") as! Elephant5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .ELEPHANT4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.HORSECOLORS
            vc.finishNumber = FinishNumbers.ELEPHANTNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.bearType {
        case .BEAR1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "BearNumber2") as! Bear2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .BEAR2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BearNumber3") as! Bear3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .BEAR3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BearNumber5") as! Bear5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .BEAR4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.HORSECOLORS
            vc.finishNumber = FinishNumbers.BEARNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.deerType {
              case .DEER1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "DeerNumber2") as! Deer2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .DEER2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "DeerNumber4") as! Deer4NumberViewController
            vc.modalTransitionStyle = .partialCurl
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .DEER3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "DeerNumber5") as! Deer5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .DEER4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.HORSECOLORS
            vc.finishNumber = FinishNumbers.DEERNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.tortoiseType {
              case .TORTOISE1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "TortoiseNumber4") as! Tortoise4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .TORTOISE2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "TortoiseNumber5") as! Tortoise5NumberViewController
            vc.modalTransitionStyle = .partialCurl
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .TORTOISE3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "TortoiseNumber3") as! Tortoise3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .TORTOISE4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.HORSECOLORS
            vc.finishNumber = FinishNumbers.TORTOISENUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.monkeyType {
              case .MONKEY1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "MonkeyNumber2") as! Monkey2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .MONKEY2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "MonkeyNumber3") as! Monkey3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .MONKEY3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "MonkeyNumber4") as! Monkey4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .MONKEY4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.finishColor = FinishColors.HORSECOLORS
            vc.finishNumber = FinishNumbers.MONKEYNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
////                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.bullType {
              case .BULL1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "BullNumber3") as! Bull3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .BULL2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BullNumber4") as! Bull4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .BULL3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BullNumber5") as! Bull5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .BULL4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.HORSECOLORS
            vc.finishNumber = FinishNumbers.BULLNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.horseType {
              case .HORSE1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "HorseNumber2") as! Horse2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .HORSE2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "HorseNumber4") as! Horse4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .HORSE3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "HorseNumber5") as! Horse5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .HORSE4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.HORSECOLORS
            vc.finishNumber = FinishNumbers.HORSENUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.carType {
              case .CAR1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "CarNumber2") as! Car2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .CAR2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "CarNumber4") as! Car4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .CAR3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "CarNumber5") as! Car5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .CAR4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.BOATCOLORS
            vc.finishNumber = FinishNumbers.CARNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.trainType {
              case .TRAIN1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "TrainNumber3") as! Train3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
        case  .TRAIN2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "TrainNumber4") as! Train4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .TRAIN3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "TrainNumber5") as! Train5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .TRAIN4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.BOATCOLORS
            vc.finishNumber = FinishNumbers.TRAINNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.lorryType {
              case .LORRY1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "LorryNumber3") as! Lorry3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .LORRY2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "LorryNumber4") as! Lorry4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .LORRY3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "LorryNumber5") as! Lorry5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .LORRY4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.BOATCOLORS
            vc.finishNumber = FinishNumbers.LORRYNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.helicopterType {
              case .HELICOPTER1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "HelicopterNumber2") as! Helicopter2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
        case  .HELICOPTER2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "HelicopterNumber3") as! Helicopter3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .HELICOPTER3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "HelicopterNumber4") as! Helicopter4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .HELICOPTER4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.BOATCOLORS
            vc.finishNumber = FinishNumbers.HELICOPTERNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.vanType {
        case .VAN1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "VanNumber2") as! Van2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .VAN2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "VanNumber4") as! Van4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .VAN3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "VanNumber5") as! Van5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .VAN4:

            let storyboard = UIStoryboard(name: "Main", bundle: nil)

            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.BOATCOLORS
            vc.finishNumber = FinishNumbers.VANNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.autoType {
              case .AUTO1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "AutoNumber3") as! Auto3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .AUTO2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "AutoNumber4") as! Auto4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .AUTO3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "AutoNumber5") as! Auto5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .AUTO4:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.BOATCOLORS
            vc.finishNumber = FinishNumbers.AUTONUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.busType {
              case .BUS1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "BusNumber2") as! Bus2NumberViewController
            vc.modalTransitionStyle = .partialCurl
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .BUS2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BusNumber4") as! Bus4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .BUS3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BusNumber6") as! Bus6NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .BUS4:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
//            vc.modalTransitionStyle = .partialCurl
            vc.finishColor = FinishColors.BOATCOLORS
            vc.finishNumber = FinishNumbers.BUSNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.bikeType {
              case .BIKE1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "BikeNumber2") as! Bike2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .BIKE2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BikeNumber3") as! Bike3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .BIKE3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BikeNumber4") as! Bike4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .BIKE4:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.BOATCOLORS
            vc.finishNumber = FinishNumbers.BIKENUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        
        switch self.jcbType {
              case .JCB1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "JcbNumber3") as! Jcb3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .JCB2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "JcbNumber4") as! Jcb4NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .JCB3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "JcbNumber5") as! Jcb5NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .JCB4:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.BOATCOLORS
            vc.finishNumber = FinishNumbers.JCBNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.boatType {
              case .BOAT1:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)

                   let vc = storyboard.instantiateViewController(withIdentifier: "BoatNumber2") as! Boat2NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .BOAT2:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BoatNumber3") as! Boat3NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .BOAT3:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "BoatNumber6") as! Boat6NumberViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .BOAT4:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.BOATCOLORS
            vc.finishNumber = FinishNumbers.BOATNUMBERS
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        switch self.colorType {
              case .APPLECOLOR:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
            print("Button Tapped")

                   let vc = storyboard.instantiateViewController(withIdentifier: "BananaColor") as! BananaColorViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
                            navigationController?.pushViewController(vc, animated: true)
        case  .BANANACOLOR:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "MangoColor") as! MangoColorViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .MANGOCOLOR:
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "OrangeColor") as! OrangeColorViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .ORANGECOLOR:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "StrawberryColor") as! StrawberryColorViewController
            vc.modalTransitionStyle = .crossDissolve
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        case .STRAWBERRYCOLOR:
             let storyboard = UIStoryboard(name: "Main", bundle: nil)
      print("Button Tapped")

             let vc = storyboard.instantiateViewController(withIdentifier: "GuavaColor") as! GuavaColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
                      navigationController?.pushViewController(vc, animated: true)
  case  .GUAVACOLOR:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "WatermelonColor") as! WatermelonColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .WATERMELONCOLOR:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "GrapeColor") as! GrapeColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
  case .GRAPECOLOR:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "PineappleColor") as! PineappleColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
            
        case .PINEAPPLECOLOR:
             let storyboard = UIStoryboard(name: "Main", bundle: nil)
      print("Button Tapped")

             let vc = storyboard.instantiateViewController(withIdentifier: "LemonColor") as! LemonColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
                      navigationController?.pushViewController(vc, animated: true)
  case  .LEMONCOLOR:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.LEMONCOLORS
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .TOMATOCOLOR:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "CarrotColor") as! CarrotColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
  case .CARROTCOLOR:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "BrinjalColor") as! BrinjalColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
       
  case  .BRINJALCOLOR:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "PotatoColor") as! PotatoColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .POTATOCOLOR:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "ChilliColor") as! ChilliColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
  case .CHILLICOLOR:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "PumpkinColor") as! PumpkinColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
            
        case .PUMPKINCOLOR:
             let storyboard = UIStoryboard(name: "Main", bundle: nil)
      print("Button Tapped")

             let vc = storyboard.instantiateViewController(withIdentifier: "CauliflowerColor") as! CauliflowerColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
                      navigationController?.pushViewController(vc, animated: true)
  case  .CAULIFLOWERCOLOR:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "CabbageColor") as! CabbageColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .CABBAGECOLOR:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "CucumberColor") as! CucumberColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
  case .CUCUMBERCOLOR:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "OnionColor") as! OnionColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
            
        
  case  .ONIONCOLOR:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.ONIONCOLORS
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .COWCOLOR:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "LionColor") as! LionColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
  case .LIONCOLOR:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "DogColor") as! DogColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
            
        case .DOGCOLOR:
             let storyboard = UIStoryboard(name: "Main", bundle: nil)
      print("Button Tapped")

             let vc = storyboard.instantiateViewController(withIdentifier: "ElephantColor") as! ElephantColorViewController
            vc.modalTransitionStyle = .partialCurl
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
                      navigationController?.pushViewController(vc, animated: true)
  case  .ELEPHANTCOLOR:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "BearColor") as! BearColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .BEARCOLOR:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "DeerColor") as! DeerColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
  case .DEERCOLOR:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "TortoiseColor") as! TortoiseColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
            
  case .TORTOISECOLOR:
             let storyboard = UIStoryboard(name: "Main", bundle: nil)
      print("Button Tapped")

             let vc = storyboard.instantiateViewController(withIdentifier: "MonkeyColor") as! MonkeyColorViewController
            vc.modalTransitionStyle = .partialCurl
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
                      navigationController?.pushViewController(vc, animated: true)
  case  .MONKEYCOLOR:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "BullColor") as! BullColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .BULLCOLOR:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "HorseColor") as! HorseColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
  case .HORSECOLOR:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = FinishColors.HORSECOLORS
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
            
            
  case .CARCOLOR:
             let storyboard = UIStoryboard(name: "Main", bundle: nil)
      print("Button Tapped")

             let vc = storyboard.instantiateViewController(withIdentifier: "TrainColor") as! TrainColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
                      navigationController?.pushViewController(vc, animated: true)
  case  .TRAINCOLOR:

      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      let vc = storyboard.instantiateViewController(withIdentifier: "LorryColor") as! LorryColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
      
  case .LORRYCOLOR:
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "HelicopterColor") as! HelicopterColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
      
  case .HELICOPTERCOLOR:
      
      let storyboard = UIStoryboard(name: "Main", bundle: nil)
      
      let vc = storyboard.instantiateViewController(withIdentifier: "VanColor") as! VanColorViewController
            vc.modalTransitionStyle = .crossDissolve
      vc.modalPresentationStyle = .fullScreen
      self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
  case .VANCOLOR:
       let storyboard = UIStoryboard(name: "Main", bundle: nil)
print("Button Tapped")

       let vc = storyboard.instantiateViewController(withIdentifier: "AutoColor") as! AutoColorViewController
            vc.modalTransitionStyle = .crossDissolve
vc.modalPresentationStyle = .fullScreen
self.present(vc, animated: true, completion: nil)
                navigationController?.pushViewController(vc, animated: true)
case  .AUTOCOLOR:

let storyboard = UIStoryboard(name: "Main", bundle: nil)
let vc = storyboard.instantiateViewController(withIdentifier: "BusColor") as! BusColorViewController
            vc.modalTransitionStyle = .crossDissolve
vc.modalPresentationStyle = .fullScreen
self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)


case .BUSCOLOR:
let storyboard = UIStoryboard(name: "Main", bundle: nil)

let vc = storyboard.instantiateViewController(withIdentifier: "BikeColor") as! BikeColorViewController
            vc.modalTransitionStyle = .crossDissolve
vc.modalPresentationStyle = .fullScreen
self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)

case .BIKECOLOR:

let storyboard = UIStoryboard(name: "Main", bundle: nil)

let vc = storyboard.instantiateViewController(withIdentifier: "JcbColor") as! JcbColorViewController
            vc.modalTransitionStyle = .crossDissolve
vc.modalPresentationStyle = .fullScreen
self.present(vc, animated: true, completion: nil)
      
  case .JCBCOLOR:
       let storyboard = UIStoryboard(name: "Main", bundle: nil)
print("Button Tapped")

       let vc = storyboard.instantiateViewController(withIdentifier: "BoatColor") as! BoatColorViewController
            vc.modalTransitionStyle = .crossDissolve
vc.modalPresentationStyle = .fullScreen
self.present(vc, animated: true, completion: nil)
                navigationController?.pushViewController(vc, animated: true)
case  .BOATCOLOR:

let storyboard = UIStoryboard(name: "Main", bundle: nil)
let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
            vc.finishColor = .BOATCOLORS
vc.modalPresentationStyle = .fullScreen
self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        default: break
          }
        }
    }
