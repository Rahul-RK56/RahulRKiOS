//
//  VanNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class VanNumberViewController: UIViewController {
    
    
    @IBOutlet weak var vanOption3: UIImageView!
    
    @IBOutlet weak var vanOption4: UIImageView!
    
    @IBOutlet weak var vanOption5: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA32 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption214))
        vanOption3.addGestureRecognizer(optionA32)
        vanOption3.isUserInteractionEnabled = true
        
        let optionB32 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption414))
        vanOption4.addGestureRecognizer(optionB32)
        vanOption4.isUserInteractionEnabled = true
        
        let optionC32 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption514))
        vanOption5.addGestureRecognizer(optionC32)
        vanOption5.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption214(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.vanType = .VAN1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption414(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.vanType = .VAN1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption514(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.vanType = .VAN1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vehicleType =  VehiclesType.VAN
        self.present(vc, animated: true, completion: nil)
    }
    
}
