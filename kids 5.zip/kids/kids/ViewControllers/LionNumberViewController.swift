//
//  LionNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 24/05/22.
//

import UIKit

class LionNumberViewController: UIViewController {
    
    @IBOutlet weak var option37: UIImageView!
    
    @IBOutlet weak var option47: UIImageView!
    
    @IBOutlet weak var option57: UIImageView!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA19 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption37))
        option37.addGestureRecognizer(optionA19)
        option37.isUserInteractionEnabled = true
        
        let optionB19 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption47))
        option47.addGestureRecognizer(optionB19)
        option47.isUserInteractionEnabled = true
        
        let optionC19 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption57))
        option57.addGestureRecognizer(optionC19)
        option57.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption37(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.lionType = .LION1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption47(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.lionType = .LION1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption57(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.lionType = .LION1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve

        vc.animalType =  AnimalsType.LION
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func menuButton(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
}
