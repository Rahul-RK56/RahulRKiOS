//
//  TypesKidsViewController.swift
//  kids
//
//  Created by CIPL0957 on 17/05/22.
//

import UIKit

enum FruitsType {
  case APPLE
  case BANANA
  case MANGO
  case ORANGE
  case STRAWBERY
  case GUAVA
  case WATERMELON
  case GRAPE
  case PINEAPPLE
  case LEMON
}

enum VegetablesType {
  case TOMATO
  case CARROT
  case BRINJAL
  case POTATO
  case CHILLI
  case PUMPKIN
  case CAULIFLOWER
  case CABBAGE
  case CUCUMBER
  case ONION
}

enum AnimalsType {
  case COW
  case LION
  case DOG
  case ELEPHANT
  case BEAR
  case DEER
  case TORTOISE
  case MONKEY
  case BULL
  case HORSE
}

enum VehiclesType {
  case CAR
  case TRAIN
  case LORRY
  case HELICOPTER
  case VAN
  case AUTO
  case BUS
  case BIKE
  case JCB
  case BOAT

}

class TypesKidsViewController: UIViewController {

    @IBOutlet weak var ANImage: UIImageView!
    
    @IBOutlet weak var ACImage: UIImageView!
    
    
    
//    var fruitName:String = ""
//
//    var vegetableName:String = ""
//
//    var animalName:String = ""
//
//    var vehicleName:String = ""
    
    var fruitType: FruitsType?
    var vegetableType: VegetablesType?
    var animalType: AnimalsType?
    var vehicleType: VehiclesType?
    var appleType: ApplesType?
    var bananaType: BananasType?
    var mangoType: MangoesType?
    var orangeType: OrangesType?
    var strawberryType: StrawberriesType?
    var guavaType: GuavasType?
    var watermelonType: WatermelonsType?
    var grapeType: GrapesType?
    var pineappleType: PineapplesType?
    var lemonType: LemonsType?
    var tomatoType: TomatoesType?
    var carrotType: CarrotsType?
    var brinjalType: BrinjalsType?
    var potatoType: PotatoesType?
    var chilliType: ChilliesType?
    var pumpkinType: PumpkinsType?
    var cauliflowerType: CauliflowersType?
    var cabbageType: CabbagesType?
    var cucumberType: CucumbersType?
    var onionType: OnionsType?
    var cowType: CowsTypes?
    var lionType: LionsTypes?
    var dogType: DogsTypes?
    var elephantType: ElephantsTypes?
    var bearType: BearsTypes?
    var deerType: DeersTypes?
    var tortoiseType: TortoisesTypes?
    var monkeyType: MonkiesTypes?
    var bullType: BullsTypes?
    var horseType: HorsesTypes?
    var carType: CarsTypes?
    var trainType: TrainsTypes?
    var lorryType: LorriesTypes?
    var helicopterType: HelicoptersTypes?
    var vanType: VansTypes?
    var autoType: AutosTypes?
    var busType: BusesTypes?
    var bikeType: BikesTypes?
    var jcbType: JcbTypes?
    var boatType: BoatsTypes?
    var colorType: ColorsType?


    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        print(fruitName)

        // Do any additional setup after loading the view.
        let tapGR20 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped20))
        ANImage.addGestureRecognizer(tapGR20)
        ANImage.isUserInteractionEnabled = true
        
        
        let tapGR21 = UITapGestureRecognizer(target: self, action: #selector(self.imageTapped21))
        ACImage.addGestureRecognizer(tapGR21)
        ACImage.isUserInteractionEnabled = true
    }
    
    
    @objc func imageTapped20(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                
                switch self.fruitType {
                      case .APPLE:
                           let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                           let vc = storyboard.instantiateViewController(withIdentifier: "AppleNumber") as! AppleNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
                case  .BANANA:
              
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BananaNumber") as! BananaNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .MANGO:
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "MangoNumber") as! MangoNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .ORANGE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "OrangeNumber") as! OrangeNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .STRAWBERY:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "StrawberryNumber") as! StrawberryNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .GUAVA:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "GuavaNumber") as! GuavaNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .WATERMELON:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "WatermelonNumber") as! WatermelonNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .GRAPE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "GrapeNumber") as! GrapeNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .PINEAPPLE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "PineappleNumber") as! PineappleNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .LEMON:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "LemonNumber") as! LemonNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                    
                    
                    default: break
                      }
                
//                if fruitName == "apple"{
//
//                }else if fruitName == "banana"{
//
//
//                }
             
                switch self.vegetableType {
                      case .TOMATO:
                           let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                           let vc = storyboard.instantiateViewController(withIdentifier: "TomatoNumber") as! TomatoNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
                case  .CARROT:
              
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "CarrotNumber") as! CarrotNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .BRINJAL:
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BrinjalNumber") as! BrinjalNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .POTATO:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "PotatoNumber") as! PotatoNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .CHILLI:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "ChilliNumber") as! ChilliNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .PUMPKIN:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "PumpkinNumber") as! PumpkinNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .CAULIFLOWER:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "CauliflowerNumber") as! CauliflowerNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .CABBAGE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "CabbageNumber") as! CabbageNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .CUCUMBER:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "CucumberNumber") as! CucumberNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .ONION:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "OnionNumber") as! OnionNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                    default: break
                      }
                
                switch self.animalType {
                      case .COW:
                           let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                           let vc = storyboard.instantiateViewController(withIdentifier: "CowNumber") as! CowNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
                case  .LION:
              
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "LionNumber") as! LionNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .DOG:
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "DogNumber") as! DogNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .ELEPHANT:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "ElephantNumber") as! ElephantNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .BEAR:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BearNumber") as! BearNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .DEER:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "DeerNumber") as! DeerNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .TORTOISE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "TortoiseNumber") as! TortoiseNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .MONKEY:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "MonkeyNumber") as! MonkeyNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .BULL:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BullNumber") as! BullNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .HORSE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "HorseNumber") as! HorseNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                    
                    default: break
                      }
                
                switch self.vehicleType {
                      case .CAR:
                           let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                           let vc = storyboard.instantiateViewController(withIdentifier: "CarNumber") as! CarNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
                case  .TRAIN:
              
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "TrainNumber") as! TrainNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .LORRY:
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "LorryNumber") as! LorryNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .HELICOPTER:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "HelicopterNumber") as! HelicopterNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .VAN:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "VanNumber") as! VanNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .AUTO:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "AutoNumber") as! AutoNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .BUS:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BusNumber") as! BusNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .BIKE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BikeNumber") as! BikeNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .JCB:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "JcbNumber") as! JcbNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .BOAT:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BoatNumber") as! BoatNumberViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                    default: break
                      }
           }
        }
    
    @objc func imageTapped21(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
//                let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//                let vc = storyboard.instantiateViewController(withIdentifier: "AC") as! ACViewController
//
//                navigationController?.pushViewController(vc, animated: true)
                
           
                switch self.fruitType {
                      case .APPLE:
                           let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                           let vc = storyboard.instantiateViewController(withIdentifier: "AppleColor") as! AppleColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
                case  .BANANA:
              
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BananaColor") as! BananaColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                
                case .MANGO:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "MangoColor") as! MangoColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .ORANGE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "OrangeColor") as! OrangeColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .STRAWBERY:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "StrawberryColor") as! StrawberryColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .GUAVA:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "GuavaColor") as! GuavaColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .WATERMELON:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "WatermelonColor") as! WatermelonColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .GRAPE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "GrapeColor") as! GrapeColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .PINEAPPLE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "PineappleColor") as! PineappleColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .LEMON:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "LemonColor") as! LemonColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                    
                    default: break
                      }
        
                switch self.vegetableType {
                      case .TOMATO:
                           let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                           let vc = storyboard.instantiateViewController(withIdentifier: "TomatoColor") as! TomatoColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
                case  .CARROT:
              
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "CarrotColor") as! CarrotColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                
                case .BRINJAL:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BrinjalColor") as! BrinjalColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .POTATO:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "PotatoColor") as! PotatoColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .CHILLI:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "ChilliColor") as! ChilliColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .PUMPKIN:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "PumpkinColor") as! PumpkinColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .CAULIFLOWER:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "CauliflowerColor") as! CauliflowerColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .CABBAGE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "CabbageColor") as! CabbageColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .CUCUMBER:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "CucumberColor") as! CucumberColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .ONION:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "OnionColor") as! OnionColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                    default: break
                      }
                
                
                switch self.animalType {
                      case .COW:
                           let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                           let vc = storyboard.instantiateViewController(withIdentifier: "CowColor") as! CowColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
                case  .LION:
              
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "LionColor") as! LionColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                
                case .DOG:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "DogColor") as! DogColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .ELEPHANT:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "ElephantColor") as! ElephantColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .BEAR:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BearColor") as! BearColorViewController
                    vc.modalTransitionStyle = .crossDissolve
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .DEER:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "DeerColor") as! DeerColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .TORTOISE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "TortoiseColor") as! TortoiseColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .MONKEY:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "MonkeyColor") as! MonkeyColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .BULL:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BullColor") as! BullColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                case .HORSE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "HorseColor") as! HorseColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                    
                    
                    default: break
                      }
                
                switch self.vehicleType {
                      case .CAR:
                           let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                           let vc = storyboard.instantiateViewController(withIdentifier: "CarColor") as! CarColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
                case  .TRAIN:
              
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "TrainColor") as! TrainColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                
                case .LORRY:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "LorryColor") as! LorryColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .HELICOPTER:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "HelicopterColor") as! HelicopterColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .VAN:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "VanColor") as! VanColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .AUTO:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "AutoColor") as! AutoColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .BUS:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BusColor") as! BusColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .BIKE:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BikeColor") as! BikeColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .JCB:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "JcbColor") as! JcbColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
                    vc.modalTransitionStyle = .crossDissolve
//                    navigationController?.pushViewController(vc, animated: true)
                    
                case .BOAT:
                    
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    
                    let vc = storyboard.instantiateViewController(withIdentifier: "BoatColor") as! BoatColorViewController
                    vc.modalPresentationStyle = .fullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
                    
                    
                    
                    default: break
                      }
           }
        }
    
    

    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//
//        let vc = storyboard.instantiateViewController(withIdentifier: "CategoryKids") as! CategoryKidsViewController
//        vc.modalPresentationStyle = .custom
//        self.present(vc, animated: true, completion: nil)
        
        switch self.fruitType {
              case .APPLE:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
                   let vc = storyboard.instantiateViewController(withIdentifier: "Fruits") as! FruitsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
        case  .BANANA:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Fruits") as! FruitsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        
        case .MANGO:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Fruits") as! FruitsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .ORANGE:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Fruits") as! FruitsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .STRAWBERY:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Fruits") as! FruitsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .GUAVA:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Fruits") as! FruitsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .WATERMELON:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Fruits") as! FruitsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .GRAPE:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Fruits") as! FruitsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .PINEAPPLE:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Fruits") as! FruitsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .LEMON:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Fruits") as! FruitsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
            
            default: break
              }

        switch self.vegetableType {
              case .TOMATO:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
                   let vc = storyboard.instantiateViewController(withIdentifier: "Vegetables") as! VegetablesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
        case  .CARROT:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vegetables") as! VegetablesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        
        case .BRINJAL:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vegetables") as! VegetablesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .POTATO:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vegetables") as! VegetablesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .CHILLI:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vegetables") as! VegetablesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .PUMPKIN:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vegetables") as! VegetablesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .CAULIFLOWER:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vegetables") as! VegetablesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .CABBAGE:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vegetables") as! VegetablesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .CUCUMBER:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vegetables") as! VegetablesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .ONION:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vegetables") as! VegetablesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
            default: break
              }
        
        
        switch self.animalType {
              case .COW:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
                   let vc = storyboard.instantiateViewController(withIdentifier: "Animals") as! AnimalsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
        case  .LION:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Animals") as! AnimalsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        
        case .DOG:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Animals") as! AnimalsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .ELEPHANT:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Animals") as! AnimalsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .BEAR:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Animals") as! AnimalsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .DEER:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Animals") as! AnimalsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .TORTOISE:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Animals") as! AnimalsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .MONKEY:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Animals") as! AnimalsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .coverVertical
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .BULL:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Animals") as! AnimalsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
        case .HORSE:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Animals") as! AnimalsKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
            
            
            default: break
              }
        
        switch self.vehicleType {
              case .CAR:
                   let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
                   let vc = storyboard.instantiateViewController(withIdentifier: "Vehicles") as! VehiclesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                            navigationController?.pushViewController(vc, animated: true)
        case  .TRAIN:
      
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vehicles") as! VehiclesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
        
        case .LORRY:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vehicles") as! VehiclesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .HELICOPTER:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vehicles") as! VehiclesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .VAN:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vehicles") as! VehiclesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .AUTO:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vehicles") as! VehiclesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .BUS:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vehicles") as! VehiclesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .BIKE:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vehicles") as! VehiclesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .JCB:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vehicles") as! VehiclesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
        case .BOAT:
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let vc = storyboard.instantiateViewController(withIdentifier: "Vehicles") as! VehiclesKidsViewController
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true, completion: nil)
//                    navigationController?.pushViewController(vc, animated: true)
            
            
            
            default: break
              }
        
    }
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }

}
