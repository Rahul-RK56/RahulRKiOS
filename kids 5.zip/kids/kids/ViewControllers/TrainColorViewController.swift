//
//  TrainColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 25/05/22.
//

import UIKit

class TrainColorViewController: UIViewController {
    
    @IBOutlet weak var optionBrown13: UIImageView!
    
    @IBOutlet weak var optionBlack13: UIImageView!
    
    @IBOutlet weak var optionGreen13: UIImageView!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA28 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBrown13))
        optionBrown13.addGestureRecognizer(optionA28)
        optionBrown13.isUserInteractionEnabled = true
        
        let optionB28 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBlack13))
        optionBlack13.addGestureRecognizer(optionB28)
        optionBlack13.isUserInteractionEnabled = true
        
        let optionC28 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionGreen13))
        optionGreen13.addGestureRecognizer(optionC28)
        optionGreen13.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionBrown13(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.TRAINCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionBlack13(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.TRAINCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionGreen13(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.TRAINCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vehicleType =  VehiclesType.TRAIN
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func menuButton(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        self.present(vc, animated: true, completion: nil)
    }
}
