//
//  popViewController.swift
//  kids
//
//  Created by CIPL0957 on 18/05/22.
//

import UIKit


class PopViewController: UIViewController,UITextFieldDelegate {
    
    
    @IBOutlet weak var nameTxtFld: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        nameTxtFld.background(colorScheme == .dark ? Color.black : Color.white)
//        nameTxtFld.layer.cornerRadius = 4
        nameTxtFld.textColor = .black// UIColor(named: "text_color")
        let redColor = UIColor.red
        nameTxtFld.layer.borderWidth = 1
        nameTxtFld.layer.borderColor = redColor.cgColor
        nameTxtFld.attributedPlaceholder =  NSAttributedString(
            string: "Enter Your Nick Name",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray]
        )
        
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       
       if textField == self.nameTxtFld {
         self.nameTxtFld.becomeFirstResponder()
       }
       textField.resignFirstResponder()
       return true
       
     }
    func checkEnglishFormat(string: String?, str: String?) -> Bool{

           if string == ""{ //BackSpace
              
               return true
               
           }else if str!.count > 10{

               return false
           }
           return true
       }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range:NSRange, replacementString string: String) -> Bool {
        if range.location == 0 && string == " " {
            return false
        }

            let str = (textField.text! as NSString).replacingCharacters(in: range, with: string)

            if textField == nameTxtFld{

                return checkEnglishFormat(string: string, str: str)

            }else{

                return true
            }
        }
    @IBAction func submitButton(_ sender: UIButton) {
        if nameTxtFld.text?.isEmpty == true{
            print("No Data Found")
//            navigationController?.popViewController(animated: true)
//            dismiss(animated: true)
//            self.dismiss(animated: true, completion: nil)
//            self.present(vc, animated: true)
//            displayAlertMessage(messageToDisplay: "Enter Your Name")
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "Alert") as! AlertPopupViewController
            vc.modalPresentationStyle = .custom
//            vc.modalTransitionStyle = .crossDissolve
            self.present(vc, animated: true)
//            dismiss(animated: true)
        }else {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "CategoryKids") as! CategoryKidsViewController
        vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            
        vc.text = nameTxtFld.text
            
            UserDefaults.standard.set(nameTxtFld.text, forKey: "name")
            
        self.present(vc, animated: true, completion: nil)
//       self.navigationController?.pushViewController(vc, animated: true)
        }
        
//        
    
   }
}
