//
//  OnionColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 10/06/22.
//

import UIKit

class OnionColorViewController: UIViewController {
    @IBOutlet weak var onionOptionOrange: UIImageView!
    @IBOutlet weak var onionOptionRed: UIImageView!
    @IBOutlet weak var onionOptionYellow: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA22 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionOrange13))
        onionOptionOrange.addGestureRecognizer(optionA22)
        onionOptionOrange.isUserInteractionEnabled = true
        
        let optionB22 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionRed13))
        onionOptionRed.addGestureRecognizer(optionB22)
        onionOptionRed.isUserInteractionEnabled = true
        
        let optionC22 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionYellow13))
        onionOptionYellow.addGestureRecognizer(optionC22)
        onionOptionYellow.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOptionOrange13(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Finish") as! FinishViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.finishColor = FinishColors.ONIONCOLORS
                vc.finishNumber = FinishNumbers.TOMATONUMBERS

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionRed13(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.ONIONCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionYellow13(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.ONIONCOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vegetableType =  VegetablesType.ONION
        self.present(vc, animated: true, completion: nil)
    }
    
}
