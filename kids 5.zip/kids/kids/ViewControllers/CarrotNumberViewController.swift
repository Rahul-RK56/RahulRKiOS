//
//  CaarrotNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 23/05/22.
//

import UIKit

class CarrotNumberViewController: UIViewController {
    
    @IBOutlet weak var option33: UIImageView!
    
    @IBOutlet weak var option43: UIImageView!
    
    @IBOutlet weak var option53: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA11 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption33))
        option33.addGestureRecognizer(optionA11)
        option33.isUserInteractionEnabled = true
        
        let optionB11 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption43))
        option43.addGestureRecognizer(optionB11)
        option43.isUserInteractionEnabled = true
        
        let optionC11 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption53))
        option53.addGestureRecognizer(optionC11)
        option53.isUserInteractionEnabled = true
    }
    
    @objc func imageTappedOption33(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.carrotType = .CARROT1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption43(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.carrotType = .CARROT1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption53(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.carrotType = .CARROT1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func backButton(_ sender: Any) {
        
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vegetableType =  VegetablesType.CARROT
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
}
