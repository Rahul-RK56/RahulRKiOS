//
//  StrawberryNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 09/06/22.
//

import UIKit

class StrawberryNumberViewController: UIViewController {

    @IBOutlet weak var strawberryOption3: UIImageView!
    
    @IBOutlet weak var strawberryOption4: UIImageView!
    
    @IBOutlet weak var strawberryOption5: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let optionA10 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption32))
        strawberryOption3.addGestureRecognizer(optionA10)
        strawberryOption3.isUserInteractionEnabled = true
        
        let optionB10 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption42))
        strawberryOption4.addGestureRecognizer(optionB10)
        strawberryOption4.isUserInteractionEnabled = true
        
        let optionC10 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption52))
        strawberryOption5.addGestureRecognizer(optionC10)
        strawberryOption5.isUserInteractionEnabled = true
    }
    @objc func imageTappedOption32(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.strawberryType = .STRAWBERRY1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption42(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.strawberryType = .STRAWBERRY1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption52(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.strawberryType = .STRAWBERRY1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.fruitType =  FruitsType.STRAWBERY
        self.present(vc, animated: true, completion: nil)
    }
    
}
