//
//  BearNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class BearNumberViewController: UIViewController {
    @IBOutlet weak var bearOption3: UIImageView!
    @IBOutlet weak var bearOption4: UIImageView!
    @IBOutlet weak var bearOption5: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA24 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption30))
        bearOption3.addGestureRecognizer(optionA24)
        bearOption3.isUserInteractionEnabled = true
        
        let optionB24 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption40))
        bearOption4.addGestureRecognizer(optionB24)
        bearOption4.isUserInteractionEnabled = true
        
        let optionC24 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption50))
        bearOption5.addGestureRecognizer(optionC24)
        bearOption5.isUserInteractionEnabled = true
    }
    @objc func imageTappedOption30(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.bearType = .BEAR1

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption40(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.bearType = .BEAR1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption50(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.bearType = .BEAR1

                self.present(vc, animated: true, completion: nil)
        
           }
        }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.BEAR
        self.present(vc, animated: true, completion: nil)
    }
}
