//
//  ChilliNumberViewController.swift
//  kids
//
//  Created by CIPL0957 on 10/06/22.
//

import UIKit

class ChilliNumberViewController: UIViewController {
    @IBOutlet weak var chilliOption3: UIImageView!
    
    @IBOutlet weak var chilliOption4: UIImageView!
    
    @IBOutlet weak var chilliOption5: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let optionA16 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption36))
        chilliOption3.addGestureRecognizer(optionA16)
        chilliOption3.isUserInteractionEnabled = true
        
        let optionB16 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption46))
        chilliOption4.addGestureRecognizer(optionB16)
        chilliOption4.isUserInteractionEnabled = true
        
        let optionC16 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOption56))
        chilliOption5.addGestureRecognizer(optionC16)
        chilliOption5.isUserInteractionEnabled = true
    }
    @objc func imageTappedOption36(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.chilliType = .CHILLI1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption46(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.chilliType = .CHILLI1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOption56(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.chilliType = .CHILLI1
                self.present(vc, animated: true, completion: nil)
        
           }
        }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
   
    @IBAction func backButton(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.vegetableType =  VegetablesType.CHILLI
        self.present(vc, animated: true, completion: nil)
    }
    
}
