//
//  SplashScreenViewController.swift
//  kids
//
//  Created by CIPL0957 on 29/06/22.
//

import UIKit
import NVActivityIndicatorView

class SplashScreenViewController: UIViewController {
    @IBOutlet weak var loader: NVActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loader.startAnimating()
        Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(dismissSplashController), userInfo: nil, repeats: false)  // Do any additional setup after loading the view.
    }
    @objc func dismissSplashController() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "Login") as! LoginKidsViewController
//        navigationController?.pushViewController(vc, animated: true)
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    

}
