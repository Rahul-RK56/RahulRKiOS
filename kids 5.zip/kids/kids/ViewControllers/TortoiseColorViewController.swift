//
//  TortoiseColorViewController.swift
//  kids
//
//  Created by CIPL0957 on 14/06/22.
//

import UIKit

class TortoiseColorViewController: UIViewController {
    @IBOutlet weak var tortioseOptionBrown: UIImageView!
    
    @IBOutlet weak var tortioseOptionGreen: UIImageView!
    
    @IBOutlet weak var tortioseOptionYellow: UIImageView!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        let optionA27 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionBrown14))
        tortioseOptionBrown.addGestureRecognizer(optionA27)
        tortioseOptionBrown.isUserInteractionEnabled = true
        
        let optionB27 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionGreen14))
        tortioseOptionGreen.addGestureRecognizer(optionB27)
        tortioseOptionGreen.isUserInteractionEnabled = true
        
        let optionC27 = UITapGestureRecognizer(target: self, action: #selector(self.imageTappedOptionYellow14))
        tortioseOptionYellow.addGestureRecognizer(optionC27)
        tortioseOptionYellow.isUserInteractionEnabled = true
    }
    @objc func imageTappedOptionBrown14(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.TORTOISECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionGreen14(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Success") as! SuccessViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.TORTOISECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }
    
    @objc func imageTappedOptionYellow14(sender: UITapGestureRecognizer) {
            if sender.state == .ended {
                    print("UIImageView tapped")
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let vc = storyboard.instantiateViewController(withIdentifier: "Retry") as! RetryViewController
                vc.modalTransitionStyle = .coverVertical
                vc.modalPresentationStyle = .custom
                vc.colorType = ColorsType.TORTOISECOLOR

                self.present(vc, animated: true, completion: nil)
        
           }
        }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func menuButton(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Menu")
        vc.modalPresentationStyle = .custom
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func backButon(_ sender: Any) {
//        navigationController?.popViewController(animated: true)
//        dismiss(animated: true)
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let vc = storyboard.instantiateViewController(withIdentifier: "Types") as! TypesKidsViewController
        vc.modalTransitionStyle = .crossDissolve
        vc.modalPresentationStyle = .custom
        vc.animalType =  AnimalsType.TORTOISE
        self.present(vc, animated: true, completion: nil)
    }
}
