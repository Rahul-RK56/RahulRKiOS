//
//  AppleCell.swift
//  kids
//
//  Created by CIPL0957 on 27/05/22.
//

import UIKit

class AppleCell: UICollectionViewCell {

    @IBOutlet weak var imageview: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
