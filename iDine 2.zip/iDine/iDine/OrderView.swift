//
//  OrderView.swift
//  iDine
//
//  Created by CIPL1283 on 31/10/22.
//

import SwiftUI

struct OrderView: View {
    @EnvironmentObject var order:Order
    var body: some View {
        NavigationView{
            List{
                Section{
                    ForEach(order.items) { items in
                        HStack{
                            Text("\(items.name)")
                            Spacer()
                            Text("$\(items.price)")
                        }
                    }
                }
                Section{
                    NavigationLink(destination: Text("Cdeck Out")){
                        Text("Place Order")
                    }
                }
            }
            .navigationTitle("Order")
        }
    }
}

struct OrderView_Previews: PreviewProvider {
    static var previews: some View {
        OrderView()
            .environmentObject(Order())
    }
}
