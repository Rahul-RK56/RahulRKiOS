//
//  itemDetail.swift
//  iDine
//
//  Created by CIPL1283 on 31/10/22.
//

import SwiftUI

struct ItemDetail: View {
    @EnvironmentObject var order:Order
    let item:MenuItem
    var body: some View {
        VStack{
            ZStack(alignment: .bottomTrailing){
                Image(item.mainImage)
                    .resizable()
                    .scaledToFit()
                Text(item.photoCredit)
                    .padding(5)
                    .background(.black)
                    .foregroundColor(.white)
                    .offset(x:-5,y:-5)
            }
            
            Text(item.description)
                .padding()
            Button("Order Item"){
                order.add(item: item)
            }.font(.headline)
            Spacer()
        }
        .navigationTitle(item.name)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct itemDetail_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            ItemDetail(item:MenuItem.example)
                .environmentObject(Order())
        }
    }
}
