//
//  iDineApp.swift
//  iDine
//
//  Created by CIPL1283 on 31/10/22.
//

import SwiftUI

@main
struct iDineApp: App {
    @StateObject var orders = Order()
    var body: some Scene {
        WindowGroup {
            MainView()
                .environmentObject(orders)
        }
    }
}
