//
//  itemRow.swift
//  iDine
//
//  Created by CIPL1283 on 31/10/22.
//

import SwiftUI

struct ItemRow: View {
    
    let color : [String:Color] = ["D":.purple,"G":.black,"N":.red,"S":.blue,"V":.green]
    
    let menuItem: MenuItem
    var body: some View {
        HStack{
            Image(menuItem.thumbnailImage)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.gray, style: StrokeStyle(lineWidth: 2)))
            VStack(alignment: .leading){
                Text(menuItem.name)
                Text("\(menuItem.price)")
            }
            Spacer()
            ForEach(menuItem.restrictions, id: \.self) { restriction in
                Text(restriction)
                    .font(.caption)
                    .fontWeight(.bold)
                    .padding(5)
                    .background(color[restriction,default: .black])
                    .clipShape(Circle())
                    .foregroundColor(.white)
                    
            }
        }
    }
}

struct itemRow_Previews: PreviewProvider {
    static var previews: some View {
        ItemRow(menuItem:MenuItem.example)
    }
}
