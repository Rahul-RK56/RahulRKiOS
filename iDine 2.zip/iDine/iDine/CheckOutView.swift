//
//  CheckOutView.swift
//  iDine
//
//  Created by CIPL1283 on 31/10/22.
//

import SwiftUI

struct CheckOutView: View {
    @EnvironmentObject var order:Order
    
    let paymentType = ["cash","Credit card","iDine points"]
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CheckOutView_Previews: PreviewProvider {
    static var previews: some View {
        CheckOutView()
            .environmentObject(Order())
    }
}
