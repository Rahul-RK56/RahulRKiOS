//
//  HomeView.swift
//  DemoComApp
//
//  Created by Apple on 20/12/22.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
//        NavigationView{
                 VStack {
                     NavigationLink(
                     destination: ContentView()) {
                         
                             
                                
                         Text("Log Out")
                             .font(.title)
                             .foregroundColor(Color.white)
                             .multilineTextAlignment(.center)
                             .frame(width: 300.0, height: 50.0)
                             .background(Color(UIColor.red))
                        
                     }
                     
                 }
//             }
   
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
