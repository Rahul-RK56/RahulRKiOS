//
//  DemoComAppApp.swift
//  DemoComApp
//
//  Created by Apple on 08/12/22.
//

import SwiftUI

@main
struct DemoComAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
