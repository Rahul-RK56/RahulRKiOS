//
//  ViewController.swift
//  S3BucketApp
//
//  Created by CIPL0419 on 09/09/22.
//

import UIKit
import AWSCore
import AWSS3

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
       
    }

    @IBAction func pickImage(_ sender: Any) {
        ImagePickerManager().pickImage(self){ image in
            self.imageView.image = image
            self.uploadFile(withImage: image)
        }
    }
    
    func resizedImage (image:UIImage, sizeChange:CGSize)-> UIImage{
          
        let hasAlpha = true
        let scale: CGFloat = 0.0
        
        UIGraphicsBeginImageContextWithOptions(sizeChange, !hasAlpha, scale)

        image.draw(in: CGRect(origin: CGPoint.zero, size: sizeChange))

        let scaledImage = UIGraphicsGetImageFromCurrentImageContext()

        UIGraphicsEndImageContext()

        return scaledImage!
    }
 
    func generateRandomStringWithLength(length: Int) -> String {
        let randomString: NSMutableString = NSMutableString(capacity: length)
        let letters: NSMutableString = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        var i: Int = 0

        while i < length {
            let randomIndex: Int = Int(arc4random_uniform(UInt32(letters.length)))
            randomString.append("\(Character( UnicodeScalar( letters.character(at: randomIndex))!))")
            i += 1
        }
        return String(randomString)
    }
    
    func uploadFile(withImage image: UIImage) {
        
        let s3BucketName = "alexotti2023app"

       let access = "AKIA22XTJV3FZTZ6UIWK"
       let secret = "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"
       let credentials = AWSStaticCredentialsProvider(accessKey: access, secretKey: secret)
       let configuration = AWSServiceConfiguration(region: AWSRegionType.USEast1, credentialsProvider: credentials)

       AWSServiceManager.default().defaultServiceConfiguration = configuration

       let compressedImage = resizedImage(image: image, sizeChange: CGSize(width: 80, height: 80))
       let data: Data = compressedImage.pngData()!
       let remoteName = generateRandomStringWithLength(length: 12)+"."+data.format
       print("REMOTE NAME : ",remoteName)

       let expression = AWSS3TransferUtilityUploadExpression()
       expression.progressBlock = { (task, progress) in
           DispatchQueue.main.async(execute: {
               // Update a progress bar
           })
       }

      var completionHandler: AWSS3TransferUtilityUploadCompletionHandlerBlock?
       completionHandler = { (task, error) -> Void in
           DispatchQueue.main.async(execute: {
               // Do something e.g. Alert a user for transfer completion.
               // On failed uploads, `error` contains the error object.
           })
       }

       let transferUtility = AWSS3TransferUtility.default()
       transferUtility.uploadData(data, bucket: s3BucketName, key: remoteName, contentType: "image/"+data.format, expression: expression, completionHandler: completionHandler).continueWith { (task) -> Any? in
           if let error = task.error {
               print("Error : \(error.localizedDescription)")
           }

           if task.result != nil {
               let url = AWSS3.default().configuration.endpoint.url
               let publicURL = url?.appendingPathComponent(s3BucketName).appendingPathComponent(remoteName)
               if let absoluteString = publicURL?.absoluteString {
                   // Set image with URL
                   print("Image URL : ",absoluteString)
               }
           }

           return nil
       }

   }
}

extension Data {

  var format: String {
    let array = [UInt8](self)
    let ext: String
    switch (array[0]) {
    case 0xFF:
        ext = "jpg"
    case 0x89:
        ext = "png"
    case 0x47:
        ext = "gif"
    case 0x49, 0x4D :
        ext = "tiff"
    default:
        ext = "unknown"
    }
    return ext
   }

}
