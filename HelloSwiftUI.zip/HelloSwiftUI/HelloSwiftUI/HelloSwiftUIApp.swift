//
//  HelloSwiftUIApp.swift
//  HelloSwiftUI
//
//  Created by CV on 7/14/22.
//

import SwiftUI

@main
struct HelloSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
