
import SwiftUI

struct ContentView: View {
    var body: some View {
           
        ScrollView{
            HStack() {
                HStack{
                    Button {
                        print("Edit button was tapped")
                    } label: {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                        Text("Back")
                            .foregroundColor(.black)
                            .padding(.all)
                    }.background(Color.brown)
                        .cornerRadius(5)
                    
                    Text("Home")
                        .font(.headline)
                        .multilineTextAlignment(.center)
                    Spacer()
                    }.frame(maxWidth: .infinity)
                    .background(.blue)
                    Spacer()
            }
            
                HStack() {
                    HStack{
                        Button {
                            print("Edit button was tapped")
                        } label: {
                            Image(systemName: "chevron.left")
                                .foregroundColor(.black)
                            Text("Back")
                                .foregroundColor(.black)
                        }
                        
                        
//                        Text("Home")
//                            .font(.headline)
//
                        Spacer()
                    }.frame(height: 50)
                        .background(.blue)
    //                    .padding()
    //                Spacer()
                    
                }
        }.background(.gray).padding(EdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
