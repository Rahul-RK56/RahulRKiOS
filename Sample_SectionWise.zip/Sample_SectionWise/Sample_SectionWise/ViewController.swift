//
//  ViewController.swift
//  Sample_SectionWise
//
//  Created by CIPL0209 on 13/12/22.
//

import UIKit

class ViewController: UIViewController {
    

    //MARK: Declare variables
    
    var expandedIndexSet : IndexSet = []

    var expandedA = Bool()
    var expandedB = Bool()

    
    //MARK: Create arrays
    
    var itemA = ["Apple", "Samsung", "Motorola", "Realme", "Xiaomi", "Redmi"]
    
    var itemB = ["Boat", "Noise", "Boult", "FireBolt"]

    
    @IBOutlet weak var tblViewMain: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //MARK: Register tableviewcell
        
        self.tblViewMain.register(UINib(nibName: "MainUITableViewCell", bundle: nil), forCellReuseIdentifier: "MainUITableViewCell")
       
    }
  
}
//MARK: Update TableView Cell
extension ViewController : UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
                
        switch section {
        case 0:
            if expandedA == false {
                return 3
            }else{
                expandedA = true
                return itemA.count
            }
        case 1:
            if expandedB ==  false {
                return 3
            }else{
                expandedB = true
                return itemB.count
            }
        default:
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tblViewMain.dequeueReusableCell(withIdentifier: "MainUITableViewCell", for: indexPath) as? MainUITableViewCell else {
            print("failed to get cell")
            return UITableViewCell()
        }
        cell.selectionStyle = .none
        switch (indexPath.section) {
        case 0:
            cell.lblArrData.text = itemA[indexPath.row]
        case 1:
            cell.lblArrData.text = itemB[indexPath.row]
        default:
            cell.lblArrData.text = "No Data!"
        }
        return cell
    }
     func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
         return 100.0
    }
    
     func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat{
        return 40.0
    }
     func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return "Mobile Companies"
        case 1:
            return "Accessories Companies"
     
        default:
            return "Category Unknown"
        }
        
    }

    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let Header = UIView(frame: CGRect(x: 0, y: 0, width: Double(self.tblViewMain.frame.size.width), height: 45))
        Header.backgroundColor = UIColor(named: "#2AF8AC")
        let button = UIButton()
        button.frame = CGRect(x: 0, y: 0, width: Header.frame.size.width , height: Header.frame.size.height)
        button.backgroundColor = .clear
        button.setTitle("See More", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.tag = section
        switch section {
        case 0:
            if expandedA {
                button.setTitle("Less More", for: .normal)
            }else{
                button.setTitle("See More", for: .normal)
            }
        case 1:
            if expandedB {
                button.setTitle("Less More", for: .normal)
            }else{
                button.setTitle("See More", for: .normal)
            }
        default: break
        }
        button.addTarget(self, action: #selector(seeMoreAction), for: UIControl.Event.touchUpInside)
        Header.addSubview(button)
        Header.bringSubviewToFront(button)
        return Header
  }


  func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
      return 45
  }
    @objc func seeMoreAction(sender: UIButton!) {
        if sender.tag == 0 {
            if(expandedIndexSet.contains(sender.tag)){
                expandedA = false
                expandedIndexSet.remove(sender.tag)
                print("Item A is Removed")
                tblViewMain.reloadData()
            }else{
                expandedA = true
                expandedIndexSet.insert(sender.tag)
                print("Item A is Added")
                tblViewMain.reloadData()
            }
        }else{
            if(expandedIndexSet.contains(sender.tag)) {
                expandedB = false
                expandedIndexSet.remove(sender.tag)
                print("Item B is Remove")
                tblViewMain.reloadData()
            } else {
                expandedB = true
                expandedIndexSet.insert(sender.tag)
                print("Item B is Added")
                tblViewMain.reloadData()
            }
        }
    }
}
