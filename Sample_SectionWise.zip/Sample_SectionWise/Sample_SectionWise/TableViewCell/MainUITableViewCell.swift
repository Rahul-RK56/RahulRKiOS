//
//  MainUITableViewCell.swift
//  Sample_SectionWise
//
//  Created by CIPL0209 on 13/12/22.
//

import UIKit

class MainUITableViewCell: UITableViewCell {

    @IBOutlet weak var lblArrData: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
