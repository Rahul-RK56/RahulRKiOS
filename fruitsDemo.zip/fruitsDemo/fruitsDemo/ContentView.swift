//
//  ContentView.swift
//  fruitsDemo
//
//  Created by CIPL1287 on 02/11/22.
//

import SwiftUI

struct ContentView: View {
     var isselected = Bool()
    var body: some View {
        VStack {
//            Image(systemName: "globe")
//                .imageScale(.large)
//                .foregroundColor(.accentColor)
//            Text("Press me")
//            Button("click", action: {
//
//            })
            NavigationView{
//                Button("Click Me", action: {
                NavigationLink("Click or Press Me", destination: fruitsPageView(fruitsToBeInvite: [fruits]()))
//                })
            
            }
        }
//        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
