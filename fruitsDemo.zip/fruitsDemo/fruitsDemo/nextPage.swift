//
//  nextPage.swift
//  fruitsDemo
//
//  Created by CIPL1287 on 04/11/22.
//

import SwiftUI

struct nextPage: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct nextPage_Previews: PreviewProvider {
    static var previews: some View {
        nextPage()
    }
}
