//
//  model.swift
//  fruitsDemo
//
//  Created by CIPL1287 on 02/11/22.
//

import SwiftUI

struct fruits: Identifiable{
        var name: String
        var id: Int
    }
