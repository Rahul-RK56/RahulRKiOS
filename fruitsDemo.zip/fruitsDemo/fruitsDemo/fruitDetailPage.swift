//
//  fruitDetailPage.swift
//  fruitsDemo
//
//  Created by CIPL1287 on 03/11/22.
//

import SwiftUI

struct fruitDetailPage: View {
   
    var pfru = fruits(name:"",id:0)
    var frtDummyArray = [fruits]()

    func frt(){
        print(frtDummyArray,"helloooooooo")
    }
    
    var body: some View {
        var frtDummyArray = [fruits]()
        
        var imageName = pfru.name
     var image = Image(imageName)
    
        var imageId = pfru.id

   
        VStack(spacing: 40){
            
                 
                              image
                             .resizable()
                             .aspectRatio(contentMode: .fit)
                            .frame(maxWidth: 200,maxHeight: 200)
           HStack{
               
                    Button("Previous", action: {
    //                    NavigationLink("", destination: nextPage())
                    }).font(.system(size: 30))
                    Spacer()
                        Button("Next", action: {
                            frt()
                            
                            print(imageId, "hi id..have u came")
                            ("hi frtdumyary",frtDummyArray)
                            
                            if imageId == frtDummyArray.count - 1 {
                               
                          }
                           else{
  
                                  imageId += 1
                               print(imageId, "have u incremented +++++")
                               image = Image(frtDummyArray[imageId].name)
                               
                                  

                           }
                        }).font(.system(size: 30))
                }.padding()
            }
           
        }
    }


struct fruitDetailPage_Previews: PreviewProvider {
    static var previews: some View {
        fruitDetailPage(pfru: fruits(name: "", id: 0))
    }
}
