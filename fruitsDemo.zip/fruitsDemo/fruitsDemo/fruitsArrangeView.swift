//
//  fruitsArrangeView.swift
//  fruitsDemo
//
//  Created by CIPL1287 on 10/11/22.
//

import SwiftUI

struct fruitsArrangeView: View {
    var selectedItem = [String]()
    func item(){
        print(selectedItem,"how r u -----")
    }
    var body: some View {
  
        Text(selectedItem.map{$0}.joined(separator: ","))
       
    }
   
}

struct fruitsArrangeView_Previews: PreviewProvider {
    static var previews: some View {
        fruitsArrangeView(selectedItem: [String]())
    }
}
