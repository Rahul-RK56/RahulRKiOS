//
//  fruitsPageView.swift
//  fruitsDemo
//
//  Created by CIPL1287 on 02/11/22.
//

import SwiftUI

struct fruitsPageView: View {
    
    
    @State private var searchText: String = ""
    var fruitsToBeInvite: [fruits]
    var selectedItems = [String]()
    var fruitsArray = [fruits(name: "Apple", id: 0),
                       fruits(name: "Orange", id: 1),
                       fruits(name: "Lemon", id: 2),
                       fruits(name: "Grapes", id: 3),
                       fruits(name: "Pine Apple", id: 4),
                       fruits(name: "Avacado", id: 5),
                       fruits(name: "Guava", id: 6),
                       fruits(name: "Mango", id: 7),
                       fruits(name: "Papaya", id: 8),
                       fruits(name: "Strawberry", id: 9),
                       fruits(name: "Banana", id: 10)]
    @State private var isModal: Bool = false
    var body: some View {
        
        var selectedItems = [String]()
        List(fruitsArray.filter({searchText.isEmpty ? true : $0.name.localizedStandardContains(searchText)})){ allFruits in
            
            NavigationLink(destination: fruitDetailPage(pfru: allFruits,frtDummyArray: [allFruits]) , label: {
                
            ListRow(eachFruit: allFruits)
                
                
                
                } )
        }.listRowSeparator(.hidden)
            .overlay(SearchDetails(text: $searchText).frame(width: 0, height: 0))
            .listStyle(InsetListStyle())
            .navigationTitle("Fruits")
            .toolbar {
                NavigationLink(destination: fruitsArrangeView(), label: {
                    Text("Done")
                })
            }
      
        
            .navigationViewStyle(StackNavigationViewStyle())
    }
}


struct ListRow: View{
    var fruitsArray = [fruits(name: "Apple", id: 0),
                       fruits(name: "Orange", id: 1),
                       fruits(name: "Lemon", id: 2),
                       fruits(name: "Grapes", id: 3),
                       fruits(name: "Pine Apple", id: 4),
                       fruits(name: "Avacado", id: 5),
                       fruits(name: "Guava", id: 6),
                       fruits(name: "Mango", id: 7),
                       fruits(name: "Papaya", id: 8),
                       fruits(name: "Strawberry", id: 9),
                       fruits(name: "Banana", id: 10)]
    
    var eachFruit = fruits(name: "", id: 0)
    
    
@State private var image = Image("uncheckBoxImage")
    var body: some View{
        var selectedItems = [String]()
        HStack(spacing: 0.0){
            //            Image("Apple")
            Image(eachFruit.name)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(maxWidth: 100)
            Spacer()
            //            Text("jancy")
            Text(eachFruit.name)
                .font(.system(size: 20))
            Spacer()
            if  selectedItems.contains(eachFruit.name) {
            
                image
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(maxWidth: 40)
            }
            else{
              
                image
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(maxWidth: 40)
            }
            
        }
        .onTapGesture {
            print(selectedItems,"selectedItems+++++")
            
            if  selectedItems.contains(eachFruit.name){
                selectedItems.removeAll(where: {"\($0)" == eachFruit.name})
                print(selectedItems,"selectedItems------")
                image = Image("uncheckBoxImage")
                
            }
            else {
                selectedItems.append(eachFruit.name)
                print(selectedItems,"selectedIems+++++appended")
                image = Image("checkBoxImage")
                
            }
        }
        
    }
    //            .contentShape(Circle())
    
}

struct fruitsPageView_Previews: PreviewProvider {
    static var previews: some View {
        //        let id = UUID()
        //        fruitsPageView(fruitsToBeInvite: [fruits](),selectedItems: .constant([id]))
        fruitsPageView(fruitsToBeInvite: [fruits]())
        //        view.backgroundColor = .white
    }
}

//
//                    })
//                    //                if isModal {
//                    //                             fruitsArrangeView()
//                    //                } else {
//                    //                    Button("Login") {
//                    //                        self.isModal = true
//                    //                    }
//                    //                }
//
//
//
//                    //                To present in the same page
//
//                    //                                Button("Done") {
//                    ////                        isModal = true
//                    ////                        NavigationLink("", destination: fruitsArrangeView())
//                    //
//                    //
//                    //                    }
//                    //                    .sheet(isPresented: $isModal, content:{
//                    //                        fruitsArrangeView()
//                    //                    } )
//                }
//
