//
//  fruitsDemoApp.swift
//  fruitsDemo
//
//  Created by CIPL1287 on 02/11/22.
//

import SwiftUI

@main
struct fruitsDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
