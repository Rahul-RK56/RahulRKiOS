//
//  ViewController.swift
//  Device Tracking
//
//  Created by CIPL0874 on 24/11/22.
//

import UIKit
import WebKit

class ViewController: UIViewController {

    @IBOutlet weak var mainView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        let myURL = URL(string:"https://devicetracking.colanapps.in/")
              let myRequest = URLRequest(url: myURL!)
              mainView.load(myRequest)
    }


}

